﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;
using MySql.Data.MySqlClient;

namespace SistemaFaturacao
{
    /// <summary>
    /// Formulário para criar novas faturas
    /// SIMPLIFICADO: Cliente + Artigos + Totais
    /// </summary>
    public partial class FormNovaFatura : Form
    {
        private ClienteRepositorio _clienteRepo;
        private ArtigoRepositorio _artigoRepo;
        private List<ItemFatura> _itens;
        private const decimal TAXA_IVA = 0.23m;

        public FormNovaFatura()
        {
            InitializeComponent();
            _clienteRepo = new ClienteRepositorio();
            _artigoRepo = new ArtigoRepositorio();
            _itens = new List<ItemFatura>();
        }

        private void FormNovaFatura_Load(object sender, EventArgs e)
        {
            try
            {
                ConfigurarDataGridView();
                CarregarClientes();
                CarregarArtigos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao inicializar: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void ConfigurarDataGridView()
        {
            dgvItens.AutoGenerateColumns = false;
            dgvItens.Columns.Clear();

            dgvItens.Columns.Add("colArtigo", "Artigo");
            dgvItens.Columns["colArtigo"].Width = 300;

            dgvItens.Columns.Add("colQuantidade", "Quantidade");
            dgvItens.Columns["colQuantidade"].Width = 100;

            dgvItens.Columns.Add("colPreco", "Preço Unit.");
            dgvItens.Columns["colPreco"].Width = 100;
            dgvItens.Columns["colPreco"].DefaultCellStyle.Format = "C2";

            dgvItens.Columns.Add("colSubtotal", "Subtotal");
            dgvItens.Columns["colSubtotal"].Width = 120;
            dgvItens.Columns["colSubtotal"].DefaultCellStyle.Format = "C2";
        }

        private void CarregarClientes()
        {
            var clientes = _clienteRepo.ObterTodos();
            cboCliente.DataSource = clientes;
            cboCliente.DisplayMember = "Nome";
            cboCliente.ValueMember = "Id";
        }

        private void CarregarArtigos()
        {
            var artigos = _artigoRepo.ObterTodos();
            cboArtigo.DataSource = artigos;
            cboArtigo.DisplayMember = "Nome";
            cboArtigo.ValueMember = "Id";
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboArtigo.SelectedItem == null)
                {
                    MessageBox.Show("Selecione um artigo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var artigo = cboArtigo.SelectedItem as Artigo;
                int quantidade = (int)nudQuantidade.Value;

                if (quantidade > artigo.StockAtual)
                {
                    MessageBox.Show($"Stock insuficiente! Disponível: {artigo.StockAtual}", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var item = new ItemFatura
                {
                    ArtigoId = artigo.Id,
                    NomeArtigo = artigo.Nome,
                    Quantidade = quantidade,
                    PrecoUnitario = artigo.PrecoUnitario,
                    Subtotal = quantidade * artigo.PrecoUnitario
                };

                _itens.Add(item);
                AtualizarGrid();
                CalcularTotais();

                nudQuantidade.Value = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao adicionar item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AtualizarGrid()
        {
            dgvItens.Rows.Clear();
            foreach (var item in _itens)
            {
                dgvItens.Rows.Add(item.NomeArtigo, item.Quantidade, item.PrecoUnitario, item.Subtotal);
            }
        }

        private void CalcularTotais()
        {
            decimal totalSemIVA = _itens.Sum(i => i.Subtotal);
            decimal iva = totalSemIVA * TAXA_IVA;
            decimal totalComIVA = totalSemIVA + iva;

            lblTotalSemIVA.Text = $"{totalSemIVA:C2}";
            lblIVA.Text = $"{iva:C2}";
            lblTotalComIVA.Text = $"{totalComIVA:C2}";
        }

        private void btnRemoverItem_Click(object sender, EventArgs e)
        {
            if (dgvItens.SelectedRows.Count > 0)
            {
                int index = dgvItens.SelectedRows[0].Index;
                _itens.RemoveAt(index);
                AtualizarGrid();
                CalcularTotais();
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboCliente.SelectedItem == null)
                {
                    MessageBox.Show("Selecione um cliente.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (_itens.Count == 0)
                {
                    MessageBox.Show("Adicione pelo menos um artigo.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var cliente = cboCliente.SelectedItem as Cliente;
                decimal totalSemIVA = _itens.Sum(i => i.Subtotal);
                decimal iva = totalSemIVA * TAXA_IVA;
                decimal totalComIVA = totalSemIVA + iva;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                using (var transacao = conexao.BeginTransaction())
                {
                    try
                    {
                        // Inserir cabeçalho da fatura
                        string numeroFatura = $"FT {DateTime.Now:yyyyMMddHHmmss}";

                        string sqlFatura = @"
                            INSERT INTO Faturas (NumeroFatura, ClienteId, DataEmissao, TotalSemIVA, TotalIVA, TotalComIVA, Estado)
                            VALUES (@Numero, @ClienteId, @Data, @TotalSemIVA, @IVA, @TotalComIVA, 'Pendente')";

                        int faturaId;
                        using (var cmd = new MySqlCommand(sqlFatura, conexao, transacao))
                        {
                            cmd.Parameters.AddWithValue("@Numero", numeroFatura);
                            cmd.Parameters.AddWithValue("@ClienteId", cliente.Id);
                            cmd.Parameters.AddWithValue("@Data", DateTime.Now);
                            cmd.Parameters.AddWithValue("@TotalSemIVA", totalSemIVA);
                            cmd.Parameters.AddWithValue("@IVA", iva);
                            cmd.Parameters.AddWithValue("@TotalComIVA", totalComIVA);
                            cmd.ExecuteNonQuery();
                            faturaId = (int)cmd.LastInsertedId;
                        }

                        // Inserir linhas da fatura
                        foreach (var item in _itens)
                        {
                            string sqlLinha = @"
                                INSERT INTO LinhasFatura (FaturaId, ArtigoId, Quantidade, PrecoUnitario, TaxaIVA, Subtotal)
                                VALUES (@FaturaId, @ArtigoId, @Quantidade, @Preco, @IVA, @Subtotal)";

                            using (var cmd = new MySqlCommand(sqlLinha, conexao, transacao))
                            {
                                cmd.Parameters.AddWithValue("@FaturaId", faturaId);
                                cmd.Parameters.AddWithValue("@ArtigoId", item.ArtigoId);
                                cmd.Parameters.AddWithValue("@Quantidade", item.Quantidade);
                                cmd.Parameters.AddWithValue("@Preco", item.PrecoUnitario);
                                cmd.Parameters.AddWithValue("@IVA", TAXA_IVA * 100);
                                cmd.Parameters.AddWithValue("@Subtotal", item.Subtotal);
                                cmd.ExecuteNonQuery();
                            }

                            // Atualizar stock
                            string sqlStock = "UPDATE Artigos SET StockAtual = StockAtual - @Quantidade WHERE ArtigoId = @Id";
                            using (var cmd = new MySqlCommand(sqlStock, conexao, transacao))
                            {
                                cmd.Parameters.AddWithValue("@Quantidade", item.Quantidade);
                                cmd.Parameters.AddWithValue("@Id", item.ArtigoId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        transacao.Commit();

                        MessageBox.Show(
                            $"Fatura emitida com sucesso!\n\nNúmero: {numeroFatura}\nTotal: {totalComIVA:C2}",
                            "Sucesso",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    catch
                    {
                        transacao.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao emitir fatura: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }

    // Classe auxiliar para itens da fatura
    public class ItemFatura
    {
        public int ArtigoId { get; set; }
        public string NomeArtigo { get; set; }
        public int Quantidade { get; set; }
        public decimal PrecoUnitario { get; set; }
        public decimal Subtotal { get; set; }
    }
}