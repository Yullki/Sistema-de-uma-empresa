﻿using System;
using System.Windows.Forms;

namespace SistemaFaturacao
{
    /// <summary>
    /// ============================================
    /// CLASSE PRINCIPAL DA APLICAÇÃO
    /// ============================================
    /// Ponto de entrada do programa
    /// 
    /// FLUXO:
    /// 1. Inicializa estilos visuais
    /// 2. Abre FormPrincipal
    /// 3. Inicia loop de mensagens (message pump)
    /// ============================================
    /// </summary>
    static class Program
    {
        /// <summary>
        /// Ponto de entrada principal da aplicação
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Habilita estilos visuais do Windows
            Application.EnableVisualStyles();

            // Define renderização de texto compatível
            Application.SetCompatibleTextRenderingDefault(false);

            // Inicia aplicação com FormPrincipal
            Application.Run(new FormPrincipal());
        }
    }
}