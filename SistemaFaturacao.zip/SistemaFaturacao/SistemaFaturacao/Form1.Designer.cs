﻿namespace SistemaFaturacao
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestarConexao = new System.Windows.Forms.Button();
            this.btnInserirArtigo = new System.Windows.Forms.Button();
            this.btnListarArtigos = new System.Windows.Forms.Button();
            this.btnTestarPaginacao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTestarConexao
            // 
            this.btnTestarConexao.Location = new System.Drawing.Point(141, 102);
            this.btnTestarConexao.Name = "btnTestarConexao";
            this.btnTestarConexao.Size = new System.Drawing.Size(129, 23);
            this.btnTestarConexao.TabIndex = 0;
            this.btnTestarConexao.Text = "Testar Conexão";
            this.btnTestarConexao.UseVisualStyleBackColor = true;
            this.btnTestarConexao.Click += new System.EventHandler(this.btnTestarConexao_Click);
            // 
            // btnInserirArtigo
            // 
            this.btnInserirArtigo.Location = new System.Drawing.Point(363, 214);
            this.btnInserirArtigo.Name = "btnInserirArtigo";
            this.btnInserirArtigo.Size = new System.Drawing.Size(184, 23);
            this.btnInserirArtigo.TabIndex = 1;
            this.btnInserirArtigo.Text = "Inserir Artigo Teste";
            this.btnInserirArtigo.UseVisualStyleBackColor = true;
            this.btnInserirArtigo.Click += new System.EventHandler(this.btnInserirArtigo_Click);
            // 
            // btnListarArtigos
            // 
            this.btnListarArtigos.Location = new System.Drawing.Point(363, 254);
            this.btnListarArtigos.Name = "btnListarArtigos";
            this.btnListarArtigos.Size = new System.Drawing.Size(184, 23);
            this.btnListarArtigos.TabIndex = 2;
            this.btnListarArtigos.Text = "Listar Artigos";
            this.btnListarArtigos.UseVisualStyleBackColor = true;
            this.btnListarArtigos.Click += new System.EventHandler(this.btnListarArtigos_Click);
            // 
            // btnTestarPaginacao
            // 
            this.btnTestarPaginacao.Location = new System.Drawing.Point(363, 295);
            this.btnTestarPaginacao.Name = "btnTestarPaginacao";
            this.btnTestarPaginacao.Size = new System.Drawing.Size(184, 23);
            this.btnTestarPaginacao.TabIndex = 3;
            this.btnTestarPaginacao.Text = "Testar Paginação (1000)";
            this.btnTestarPaginacao.UseVisualStyleBackColor = true;
            this.btnTestarPaginacao.Click += new System.EventHandler(this.btnTestarPaginacao_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTestarPaginacao);
            this.Controls.Add(this.btnListarArtigos);
            this.Controls.Add(this.btnInserirArtigo);
            this.Controls.Add(this.btnTestarConexao);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTestarConexao;
        private System.Windows.Forms.Button btnInserirArtigo;
        private System.Windows.Forms.Button btnListarArtigos;
        private System.Windows.Forms.Button btnTestarPaginacao;
    }
}

