﻿using System;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;
using System.Text;

namespace SistemaFaturacao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Testar conexão
        private void btnTestarConexao_Click(object sender, EventArgs e)
        {
            try
            {
                var conexaoBD = ConexaoBD.Instancia;
                bool conectado = conexaoBD.TestarConexao();

                if (conectado)
                {
                    MessageBox.Show(
                        "Conexão com MySQL estabelecida com sucesso!\n\n" +
                        "✅ Pool de conexões ativo\n" +
                        "✅ Base de dados acessível",
                        "Sucesso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show(
                        "Não foi possível conectar ao MySQL.",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Inserir artigo de teste
        private void btnInserirArtigo_Click(object sender, EventArgs e)
        {
            try
            {
                var repositorio = new ArtigoRepositorio();

                // Criar artigo de teste
                var artigo = new Artigo
                {
                    CodigoBarras = $"TEST{DateTime.Now.Ticks}",
                    Nome = "Artigo Teste",
                    Descricao = "Criado via Form1 para teste",
                    CategoriaId = 1, // Categoria Panelas (criada no script)
                    PrecoUnitario = 99.99m,
                    StockAtual = 10,
                    StockMinimo = 2
                };

                int novoId = repositorio.Inserir(artigo);

                MessageBox.Show(
                    $"Artigo inserido com sucesso!\n\nID: {novoId}\nNome: {artigo.Nome}",
                    "Sucesso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Listar todos os artigos
        private void btnListarArtigos_Click(object sender, EventArgs e)
        {
            try
            {
                var repositorio = new ArtigoRepositorio();
                var artigos = repositorio.ObterTodos();

                var sb = new StringBuilder();
                sb.AppendLine($"Total de artigos: {artigos.Count}\n");

                foreach (var artigo in artigos)
                {
                    sb.AppendLine($"ID: {artigo.Id} - {artigo.Nome}");
                    sb.AppendLine($"  Preço: €{artigo.PrecoUnitario:F2}");
                    sb.AppendLine($"  Stock: {artigo.StockAtual}");
                    sb.AppendLine();
                }

                MessageBox.Show(sb.ToString(), "Artigos", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Testar paginação (simula 1000+ utilizadores)
        private void btnTestarPaginacao_Click(object sender, EventArgs e)
        {
            try
            {
                var repositorio = new ArtigoRepositorio();

                // Simula carregar página 1 com 50 itens
                var artigos = repositorio.ObterComPaginacao(1, 50);

                MessageBox.Show(
                    $"Paginação testada!\n\n" +
                    $"Página 1, {artigos.Count} artigos carregados\n\n" +
                    "✅ Performance otimizada para +1000 registos!",
                    "Sucesso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}