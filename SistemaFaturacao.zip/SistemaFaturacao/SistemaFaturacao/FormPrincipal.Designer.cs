﻿namespace SistemaFaturacao
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelBotoes = new System.Windows.Forms.Panel();
            this.btnRelatorios = new System.Windows.Forms.Button();
            this.btnCriarFatura = new System.Windows.Forms.Button();
            this.btnGestaoClientes = new System.Windows.Forms.Button();
            this.btnGestaoArtigos = new System.Windows.Forms.Button();
            this.btnTesteCarga = new System.Windows.Forms.Button();
            this.panelBotoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(201, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(425, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sistema de Faturação";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(217, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(396, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Gestão de Armazenista - Artigos de Cozinha";
            // 
            // panelBotoes
            // 
            this.panelBotoes.BackColor = System.Drawing.Color.White;
            this.panelBotoes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBotoes.Controls.Add(this.btnRelatorios);
            this.panelBotoes.Controls.Add(this.btnCriarFatura);
            this.panelBotoes.Controls.Add(this.btnGestaoClientes);
            this.panelBotoes.Controls.Add(this.btnGestaoArtigos);
            this.panelBotoes.Location = new System.Drawing.Point(150, 150);
            this.panelBotoes.Name = "panelBotoes";
            this.panelBotoes.Size = new System.Drawing.Size(500, 350);
            this.panelBotoes.TabIndex = 2;
            // 
            // btnRelatorios
            // 
            this.btnRelatorios.BackColor = System.Drawing.Color.SlateGray;
            this.btnRelatorios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatorios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatorios.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatorios.ForeColor = System.Drawing.Color.White;
            this.btnRelatorios.Location = new System.Drawing.Point(50, 270);
            this.btnRelatorios.Name = "btnRelatorios";
            this.btnRelatorios.Size = new System.Drawing.Size(400, 60);
            this.btnRelatorios.TabIndex = 3;
            this.btnRelatorios.Text = "Relatórios e Logs";
            this.btnRelatorios.UseVisualStyleBackColor = false;
            this.btnRelatorios.Click += new System.EventHandler(this.btnRelatorios_Click);
            // 
            // btnCriarFatura
            // 
            this.btnCriarFatura.BackColor = System.Drawing.Color.Orange;
            this.btnCriarFatura.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCriarFatura.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCriarFatura.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarFatura.ForeColor = System.Drawing.Color.White;
            this.btnCriarFatura.Location = new System.Drawing.Point(50, 190);
            this.btnCriarFatura.Name = "btnCriarFatura";
            this.btnCriarFatura.Size = new System.Drawing.Size(400, 60);
            this.btnCriarFatura.TabIndex = 2;
            this.btnCriarFatura.Text = "Criar Fatura";
            this.btnCriarFatura.UseVisualStyleBackColor = false;
            this.btnCriarFatura.Click += new System.EventHandler(this.btnCriarFatura_Click);
            // 
            // btnGestaoClientes
            // 
            this.btnGestaoClientes.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnGestaoClientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGestaoClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGestaoClientes.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoClientes.ForeColor = System.Drawing.Color.White;
            this.btnGestaoClientes.Location = new System.Drawing.Point(50, 100);
            this.btnGestaoClientes.Name = "btnGestaoClientes";
            this.btnGestaoClientes.Size = new System.Drawing.Size(400, 60);
            this.btnGestaoClientes.TabIndex = 1;
            this.btnGestaoClientes.Text = "Gestão de Clientes";
            this.btnGestaoClientes.UseVisualStyleBackColor = false;
            this.btnGestaoClientes.Click += new System.EventHandler(this.btnGestaoClientes_Click);
            // 
            // btnGestaoArtigos
            // 
            this.btnGestaoArtigos.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnGestaoArtigos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGestaoArtigos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGestaoArtigos.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoArtigos.ForeColor = System.Drawing.Color.White;
            this.btnGestaoArtigos.Location = new System.Drawing.Point(50, 30);
            this.btnGestaoArtigos.Name = "btnGestaoArtigos";
            this.btnGestaoArtigos.Size = new System.Drawing.Size(400, 60);
            this.btnGestaoArtigos.TabIndex = 0;
            this.btnGestaoArtigos.Text = "Gestão de Artigos";
            this.btnGestaoArtigos.UseVisualStyleBackColor = false;
            this.btnGestaoArtigos.Click += new System.EventHandler(this.btnGestaoArtigos_Click);
            // 
            // btnTesteCarga
            // 
            this.btnTesteCarga.BackColor = System.Drawing.Color.Purple;
            this.btnTesteCarga.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTesteCarga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTesteCarga.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTesteCarga.ForeColor = System.Drawing.Color.White;
            this.btnTesteCarga.Location = new System.Drawing.Point(570, 500);
            this.btnTesteCarga.Name = "btnTesteCarga";
            this.btnTesteCarga.Size = new System.Drawing.Size(200, 46);
            this.btnTesteCarga.TabIndex = 4;
            this.btnTesteCarga.Text = "Teste de Carga";
            this.btnTesteCarga.UseVisualStyleBackColor = false;
            this.btnTesteCarga.Click += new System.EventHandler(this.btnTesteCarga_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.btnTesteCarga);
            this.Controls.Add(this.panelBotoes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Faturação - Armazenista";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPrincipal_FormClosing);
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.panelBotoes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelBotoes;
        private System.Windows.Forms.Button btnGestaoArtigos;
        private System.Windows.Forms.Button btnGestaoClientes;
        private System.Windows.Forms.Button btnRelatorios;
        private System.Windows.Forms.Button btnCriarFatura;
        private System.Windows.Forms.Button btnTesteCarga;
    }
}