﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao
{
    /// <summary>
    /// ============================================
    /// FORMULÁRIO: FormListagemArtigos
    /// ============================================
    /// Lista artigos com paginação e pesquisa
    /// 
    /// RECURSOS:
    /// - DataGridView para exibição
    /// - Paginação (essencial para +1000 artigos)
    /// - Pesquisa em tempo real
    /// - Operações CRUD (Criar, Editar, Remover)
    /// - Atualização automática
    /// 
    /// PERFORMANCE:
    /// - Carrega apenas página atual
    /// - Pool de conexões
    /// - Logs de tempo
    /// ============================================
    /// </summary>
    public partial class FormListagemArtigos : Form
    {
        // ============================================
        // CAMPOS PRIVADOS
        // ============================================

        /// <summary>
        /// Repositório para acesso aos artigos
        /// </summary>
        private readonly ArtigoRepositorio _repositorio;

        /// <summary>
        /// Página atual da paginação (começa em 1)
        /// </summary>
        private int _paginaAtual;

        /// <summary>
        /// Total de páginas disponíveis
        /// </summary>
        private int _totalPaginas;

        /// <summary>
        /// Itens por página (padrão: 50)
        /// </summary>
        private int _itensPorPagina;

        /// <summary>
        /// Filtro de pesquisa atual
        /// </summary>
        private string _filtroAtual;

        /// <summary>
        /// Artigo selecionado no DataGridView
        /// </summary>
        private Artigo _artigoSelecionado;

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Inicializa o formulário de listagem
        /// 
        /// FLUXO:
        /// 1. Inicializa componentes
        /// 2. Cria repositório
        /// 3. Define valores padrão
        /// 4. Popula ComboBox de itens por página
        /// 5. Carrega primeira página
        /// </summary>
        public FormListagemArtigos()
        {
            InitializeComponent();
            // Inicializa repositório
            _repositorio = new ArtigoRepositorio();
            // Valores padrão de paginação
            _paginaAtual = 1;
            _totalPaginas = 1;
            _itensPorPagina = 50;
            _filtroAtual = "";
            // CORRIGIDO: Popula ComboBox ANTES de definir SelectedIndex
            cboItensPorPagina.Items.Clear(); // Limpa itens existentes
            cboItensPorPagina.Items.Add("25");
            cboItensPorPagina.Items.Add("50");
            cboItensPorPagina.Items.Add("100");
            cboItensPorPagina.Items.Add("200");

            // Agora define o índice (50 itens = índice 1)
            cboItensPorPagina.SelectedIndex = 1;
        }

        // ============================================
        // EVENTOS DO FORMULÁRIO
        // ============================================

        /// <summary>
        /// Evento ao carregar o formulário
        /// FLUXO:
        /// 1. Configura colunas do DataGridView
        /// 2. Carrega artigos da página 1
        /// </summary>
        private void FormListagemArtigos_Load(object sender, EventArgs e)
        {
            try
            {
                ConfigurarDataGridView();
                CarregarArtigos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao carregar artigos:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // ============================================
        // CONFIGURAÇÃO DO DATAGRIDVIEW
        // ============================================

        /// <summary>
        /// Configura colunas do DataGridView
        /// </summary>
        private void ConfigurarDataGridView()
        {
            // Desabilita auto-geração de colunas
            dgvArtigos.AutoGenerateColumns = false;

            // Limpa colunas existentes
            dgvArtigos.Columns.Clear();

            // COLUNA: ID
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colId",
                HeaderText = "ID",
                Width = 60,
                ReadOnly = true
            });

            // COLUNA: Código de Barras
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colCodigoBarras",
                HeaderText = "Código",
                Width = 120,
                ReadOnly = true
            });

            // COLUNA: Nome
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colNome",
                HeaderText = "Nome do Artigo",
                Width = 250,
                ReadOnly = true
            });

            // COLUNA: Categoria
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colCategoria",
                HeaderText = "Categoria",
                Width = 120,
                ReadOnly = true
            });

            // COLUNA: Preço (formatação monetária)
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colPreco",
                HeaderText = "Preço (€)",
                Width = 100,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Format = "C2",
                    Alignment = DataGridViewContentAlignment.MiddleRight
                }
            });

            // COLUNA: Stock Atual
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colStock",
                HeaderText = "Stock",
                Width = 80,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Alignment = DataGridViewContentAlignment.MiddleRight
                }
            });

            // COLUNA: Stock Mínimo
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colStockMin",
                HeaderText = "Stock Mín.",
                Width = 100,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Alignment = DataGridViewContentAlignment.MiddleRight
                }
            });

            // COLUNA: Status (SEM DataPropertyName!)
            dgvArtigos.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colStatus",
                HeaderText = "Status",
                Width = 80,
                ReadOnly = true
            });

            // Configurações visuais
            dgvArtigos.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgvArtigos.EnableHeadersVisualStyles = false;
            dgvArtigos.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            dgvArtigos.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvArtigos.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        }

        // ============================================
        // CARREGAR ARTIGOS (PAGINAÇÃO)
        // ============================================

        /// <summary>
        /// Carrega artigos com paginação
        /// 
        /// ALGORITMO:
        /// 1. Chama repositório com paginação
        /// 2. Vincula resultado ao DataGridView
        /// 3. Atualiza labels de informação
        /// 4. Atualiza estado dos botões de navegação
        /// 
        /// PERFORMANCE:
        /// - Carrega apenas _itensPorPagina artigos
        /// - Usa índices no BD para busca rápida
        /// - Pool de conexões
        /// </summary>
        /// <summary>
        /// Carrega artigos com paginação
        /// </summary>
        private void CarregarArtigos()
        {
            try
            {
                // Cursor de espera
                this.Cursor = Cursors.WaitCursor;

                // Obtém artigos da página atual
                List<Artigo> artigos = _repositorio.ObterComPaginacao(
                    _paginaAtual,
                    _itensPorPagina,
                    _filtroAtual
                );

                // LIMPA DATAGRIDVIEW (remove linhas, não DataSource)
                dgvArtigos.Rows.Clear();

                // PREENCHE MANUALMENTE CADA LINHA
                foreach (var artigo in artigos)
                {
                    // Adiciona nova linha vazia
                    int rowIndex = dgvArtigos.Rows.Add();
                    DataGridViewRow row = dgvArtigos.Rows[rowIndex];

                    // Preenche cada célula individualmente
                    row.Cells["colId"].Value = artigo.Id;
                    row.Cells["colCodigoBarras"].Value = artigo.CodigoBarras;
                    row.Cells["colNome"].Value = artigo.Nome;
                    row.Cells["colCategoria"].Value = artigo.CategoriaNome ?? "Sem Categoria";
                    row.Cells["colPreco"].Value = artigo.PrecoUnitario;
                    row.Cells["colStock"].Value = artigo.StockAtual;
                    row.Cells["colStockMin"].Value = artigo.StockMinimo;

                    // CONVERTE BOOLEAN PARA TEXTO
                    row.Cells["colStatus"].Value = artigo.Ativo ? "Ativo" : "Inativo";

                    // Guarda objeto completo no Tag (para editar/remover)
                    row.Tag = artigo;

                    // FORMATAÇÃO VISUAL
                    // Destaca linha se stock baixo (vermelho)
                    if (artigo.PrecisaReposicao())
                    {
                        row.DefaultCellStyle.BackColor = Color.LightCoral;
                        row.DefaultCellStyle.ForeColor = Color.DarkRed;
                    }

                    // Destaca linha se inativo (cinza)
                    if (!artigo.Ativo)
                    {
                        row.DefaultCellStyle.ForeColor = Color.Gray;
                    }
                }

                // Atualiza informações e botões
                AtualizarInformacoes(artigos.Count);

                // Restaura cursor
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(
                    $"Erro ao carregar artigos:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Atualiza labels de informação e botões de navegação
        /// 
        /// PARÂMETRO: totalItens - número de itens carregados
        /// </summary>
        private void AtualizarInformacoes(int totalItens)
        {
            // Atualiza label de informação
            lblInfo.Text = $"Exibindo {totalItens} artigo(s) na página {_paginaAtual}";

            // Atualiza label de página
            lblPaginaAtual.Text = $"Página {_paginaAtual}";

            // Habilita/desabilita botões de navegação
            btnPaginaAnterior.Enabled = _paginaAtual > 1;
            btnProximaPagina.Enabled = totalItens == _itensPorPagina; // Se carregou página cheia, pode ter mais

            // Atualiza estado dos botões de ação
            bool temSelecao = dgvArtigos.SelectedRows.Count > 0;
            btnEditar.Enabled = temSelecao;
            btnRemover.Enabled = temSelecao;
        }        // ============================================
                 // EVENTOS DOS BOTÕES
                 // ============================================

        /// <summary>
        /// Evento: Botão Pesquisar
        /// FLUXO:
        /// 1. Captura texto de pesquisa
        /// 2. Define como filtro atual
        /// 3. Volta para página 1
        /// 4. Recarrega artigos
        /// </summary>
        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            _filtroAtual = txtPesquisa.Text.Trim();
            _paginaAtual = 1;
            CarregarArtigos();
        }

        /// <summary>
        /// Evento: Tecla Enter no TextBox de pesquisa
        /// Aciona pesquisa automaticamente
        /// </summary>
        private void txtPesquisa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnPesquisar_Click(sender, e);
                e.Handled = true; // Previne "beep"
            }
        }

        /// <summary>
        /// Evento: Botão Novo Artigo
        /// Abre formulário de cadastro em modo INSERT
        /// </summary>
        private void btnNovoArtigo_Click(object sender, EventArgs e)
        {
            try
            {
                // Cria formulário de detalhes em modo INSERT
                var formDetalhes = new FormArtigoDetalhes();

                // Abre como modal
                var resultado = formDetalhes.ShowDialog();

                // Se salvou, recarrega lista
                if (resultado == DialogResult.OK)
                {
                    CarregarArtigos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir formulário:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Evento: Botão Atualizar
        /// Recarrega página atual
        /// </summary>
        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            CarregarArtigos();
        }

        /// <summary>
        /// Evento: Botão Editar
        /// Abre formulário de detalhes em modo UPDATE
        /// </summary>
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvArtigos.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Selecione um artigo para editar.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                // CORRIGIDO: Obtém artigo do Tag da linha
                var artigo = dgvArtigos.SelectedRows[0].Tag as Artigo;

                if (artigo == null)
                {
                    MessageBox.Show(
                        "Erro ao obter dados do artigo selecionado.",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                // Cria formulário em modo UPDATE
                var formDetalhes = new FormArtigoDetalhes(artigo);

                var resultado = formDetalhes.ShowDialog();

                if (resultado == DialogResult.OK)
                {
                    CarregarArtigos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao editar artigo:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Evento: Botão Remover
        /// Remove artigo após confirmação
        /// </summary>
        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (dgvArtigos.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Selecione um artigo para remover.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                // CORRIGIDO: Obtém artigo do Tag
                var artigo = dgvArtigos.SelectedRows[0].Tag as Artigo;

                if (artigo == null)
                {
                    MessageBox.Show(
                        "Erro ao obter dados do artigo selecionado.",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                // Confirmação
                var resultado = MessageBox.Show(
                    $"Deseja realmente remover o artigo?\n\n" +
                    $"Nome: {artigo.Nome}\n" +
                    $"Código: {artigo.CodigoBarras}\n\n" +
                    "Esta ação não pode ser desfeita!",
                    "Confirmar Remoção",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (resultado == DialogResult.Yes)
                {
                    bool sucesso = _repositorio.Remover(artigo.Id);

                    if (sucesso)
                    {
                        MessageBox.Show(
                            "Artigo removido com sucesso!",
                            "Sucesso",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );

                        CarregarArtigos();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Artigo não encontrado.",
                            "Erro",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao remover artigo:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // ============================================
        // PAGINAÇÃO
        // ============================================

        /// <summary>
        /// Evento: Botão Página Anterior
        /// </summary>
        private void btnPaginaAnterior_Click(object sender, EventArgs e)
        {
            if (_paginaAtual > 1)
            {
                _paginaAtual--;
                CarregarArtigos();
            }
        }

        /// <summary>
        /// Evento: Botão Próxima Página
        /// </summary>
        private void btnProximaPagina_Click(object sender, EventArgs e)
        {
            _paginaAtual++;
            CarregarArtigos();
        }

        /// <summary>
        /// Evento: Alteração de itens por página
        /// </summary>
        private void cboItensPorPagina_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Extrai número do texto selecionado
            string textoSelecionado = cboItensPorPagina.SelectedItem.ToString();
            _itensPorPagina = int.Parse(textoSelecionado);

            // Volta para página 1
            _paginaAtual = 1;
            CarregarArtigos();
        }

        // ============================================
        // EVENTOS DO DATAGRIDVIEW
        // ============================================

        /// <summary>
        /// Evento: Seleção alterada no DataGridView
        /// Atualiza botões de ação
        /// </summary>
        private void dgvArtigos_SelectionChanged(object sender, EventArgs e)
        {
            bool temSelecao = dgvArtigos.SelectedRows.Count > 0;
            btnEditar.Enabled = temSelecao;
            btnRemover.Enabled = temSelecao;

            // Atualiza artigo selecionado
            if (temSelecao)
            {
                _artigoSelecionado = dgvArtigos.SelectedRows[0].Tag as Artigo;
            }
            else
            {
                _artigoSelecionado = null;
            }
        }

        /// <summary>
        /// Evento: Duplo clique em linha
        /// Abre edição diretamente
        /// </summary>
        private void dgvArtigos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEditar_Click(sender, e);
            }
        }
    }
}