﻿using System;

namespace SistemaFaturacao.Excecoes
{
    /// <summary>
    /// ============================================
    /// EXCEÇÃO PERSONALIZADA: ValidacaoException
    /// ============================================
    /// Lançada quando dados de entrada são inválidos
    /// 
    /// HERANÇA: Exception (classe base do .NET)
    /// 
    /// QUANDO USAR:
    /// - Nome vazio
    /// - Preço negativo
    /// - NIF inválido
    /// - Email mal formatado
    /// 
    /// FLUXO:
    /// 1. Código detecta dado inválido
    /// 2. Lança: throw new ValidacaoException("Mensagem")
    /// 3. Capturado em try-catch
    /// 4. Exibido ao utilizador
    /// ============================================
    /// </summary>
    public class ValidacaoException : Exception
    {
        // ============================================
        // CONSTRUTORES (SOBRECARGA)
        // ============================================

        /// <summary>
        /// Construtor padrão sem mensagem
        /// USO: throw new ValidacaoException();
        /// </summary>
        public ValidacaoException() : base()
        {
        }

        /// <summary>
        /// Construtor com mensagem personalizada
        /// PARÂMETRO: mensagem - descrição do erro
        /// USO: throw new ValidacaoException("Nome não pode estar vazio");
        /// 
        /// CONVENÇÃO: parâmetros em camelCase (mensagem)
        /// </summary>
        public ValidacaoException(string mensagem) : base(mensagem)
        {
        }

        /// <summary>
        /// Construtor com mensagem e exceção interna
        /// PARÂMETRO: mensagem - descrição do erro
        /// PARÂMETRO: innerException - exceção original que causou esta
        /// 
        /// USO: encadear exceções para debugging
        /// EXEMPLO: 
        /// try { ... }
        /// catch (Exception ex) {
        ///     throw new ValidacaoException("Erro ao validar", ex);
        /// }
        /// </summary>
        public ValidacaoException(string mensagem, Exception innerException)
            : base(mensagem, innerException)
        {
        }
    }
}