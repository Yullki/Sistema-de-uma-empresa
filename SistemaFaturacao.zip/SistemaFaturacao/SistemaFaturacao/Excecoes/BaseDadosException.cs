﻿using System;

namespace SistemaFaturacao.Excecoes
{
    /// <summary>
    /// ============================================
    /// EXCEÇÃO PERSONALIZADA: BancoDadosException
    /// ============================================
    /// Lançada quando ocorre erro de acesso ao MySQL
    /// 
    /// QUANDO USAR:
    /// - Conexão falhou
    /// - Timeout de query
    /// - Erro SQL (syntax, constraint)
    /// - Tabela não existe
    /// 
    /// BENEFÍCIO: 
    /// Separa erros de BD de erros de lógica
    /// Facilita tratamento específico
    /// ============================================
    /// </summary>
    public class BaseDadosException : Exception
    {
        // ============================================
        // CONSTRUTORES
        // ============================================

        /// <summary>
        /// Construtor padrão
        /// </summary>
        public BaseDadosException() : base()
        {
        }

        /// <summary>
        /// Construtor com mensagem
        /// PARÂMETRO: mensagem - descrição do erro SQL
        /// </summary>
        public BaseDadosException(string mensagem) : base(mensagem)
        {
        }

        /// <summary>
        /// Construtor com mensagem e exceção interna
        /// PARÂMETRO: mensagem - descrição amigável
        /// PARÂMETRO: innerException - exceção MySQL original
        /// 
        /// FLUXO TÍPICO:
        /// try {
        ///     // executar SQL
        /// }
        /// catch (MySqlException ex) {
        ///     throw new BancoDadosException("Erro ao inserir artigo", ex);
        /// }
        /// </summary>
        public BaseDadosException(string mensagem, Exception innerException)
            : base(mensagem, innerException)
        {
        }
    }
}