﻿using System;

namespace SistemaFaturacao.Excecoes
{
    /// <summary>
    /// ============================================
    /// EXCEÇÃO PERSONALIZADA: NegocioException
    /// ============================================
    /// Lançada quando regra de negócio é violada
    /// 
    /// QUANDO USAR:
    /// - Vender artigo sem stock
    /// - Criar fatura sem linhas
    /// - Cliente inativo
    /// - Preço inferior ao custo
    /// 
    /// DIFERENÇA das outras:
    /// - ValidacaoException: formato/tipo errado
    /// - BancoDadosException: erro técnico BD
    /// - NegocioException: regra de negócio quebrada
    /// ============================================
    /// </summary>
    public class NegocioException : Exception
    {
        // ============================================
        // CONSTRUTORES
        // ============================================

        public NegocioException() : base()
        {
        }

        /// <summary>
        /// Construtor com mensagem
        /// PARÂMETRO: mensagem - descrição da regra violada
        /// 
        /// EXEMPLO:
        /// if (artigo.StockAtual < quantidade)
        ///     throw new NegocioException("Stock insuficiente para venda");
        /// </summary>
        public NegocioException(string mensagem) : base(mensagem)
        {
        }

        public NegocioException(string mensagem, Exception innerException)
            : base(mensagem, innerException)
        {
        }
    }
}