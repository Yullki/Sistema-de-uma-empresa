﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao
{
    /// <summary>
    /// ============================================
    /// FORMULÁRIO: FormListagemClientes
    /// ============================================
    /// Lista clientes com paginação e pesquisa
    /// 
    /// PADRÃO: Idêntico ao FormListagemArtigos
    /// ============================================
    /// </summary>
    public partial class FormListagemClientes : Form
    {
        // ============================================
        // CAMPOS PRIVADOS
        // ============================================

        private readonly ClienteRepositorio _repositorio;
        private int _paginaAtual;
        private int _totalPaginas;
        private int _itensPorPagina;
        private string _filtroAtual;
        private Cliente _clienteSelecionado;

        // ============================================
        // CONSTRUTOR
        // ============================================

        public FormListagemClientes()
        {
            InitializeComponent();

            _repositorio = new ClienteRepositorio();
            _paginaAtual = 1;
            _totalPaginas = 1;
            _itensPorPagina = 50;
            _filtroAtual = "";

            PreencherComboItensPorPagina();
        }

        // ============================================
        // MÉTODO AUXILIAR
        // ============================================

        private void PreencherComboItensPorPagina()
        {
            cboItensPorPagina.Items.Clear();
            cboItensPorPagina.Items.Add("25");
            cboItensPorPagina.Items.Add("50");
            cboItensPorPagina.Items.Add("100");
            cboItensPorPagina.Items.Add("200");
            cboItensPorPagina.SelectedIndex = 1; // 50
        }

        // ============================================
        // EVENTO LOAD
        // ============================================

        private void FormListagemClientes_Load(object sender, EventArgs e)
        {
            try
            {
                ConfigurarDataGridView();
                CarregarClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao carregar clientes:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // ============================================
        // CONFIGURAÇÃO DO DATAGRIDVIEW
        // ============================================

        private void ConfigurarDataGridView()
        {
            dgvClientes.AutoGenerateColumns = false;
            dgvClientes.Columns.Clear();
            dgvClientes.Rows.Clear();

            dgvClientes.Columns.Add("colId", "ID");
            dgvClientes.Columns["colId"].Width = 60;

            dgvClientes.Columns.Add("colNome", "Nome");
            dgvClientes.Columns["colNome"].Width = 300;

            dgvClientes.Columns.Add("colTelefone", "Telefone");
            dgvClientes.Columns["colTelefone"].Width = 150;

            dgvClientes.Columns.Add("colEmail", "Email");
            dgvClientes.Columns["colEmail"].Width = 250;

            dgvClientes.Columns.Add("colStatus", "Status");
            dgvClientes.Columns["colStatus"].Width = 80;

            dgvClientes.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgvClientes.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            dgvClientes.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvClientes.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        }

        // ============================================
        // CARREGAR CLIENTES
        // ============================================

        private void CarregarClientes()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                List<Cliente> clientes = _repositorio.ObterComPaginacao(_paginaAtual, _itensPorPagina, _filtroAtual);

                dgvClientes.Rows.Clear();

                foreach (var cli in clientes)
                {
                    int idx = dgvClientes.Rows.Add(
                        cli.Id,
                        cli.Nome,
                        cli.Telefone,
                        cli.Email,
                        cli.Ativo ? "Ativo" : "Inativo"
                    );

                    dgvClientes.Rows[idx].Tag = cli;

                    if (!cli.Ativo)
                        dgvClientes.Rows[idx].DefaultCellStyle.ForeColor = Color.Gray;
                }

                AtualizarInformacoes(clientes.Count);
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ============================================
        // ATUALIZAR INFORMAÇÕES
        // ============================================

        private void AtualizarInformacoes(int totalItens)
        {
            lblInfo.Text = $"Exibindo {totalItens} cliente(s) na página {_paginaAtual}";
            lblPaginaAtual.Text = $"Página {_paginaAtual}";

            btnPaginaAnterior.Enabled = _paginaAtual > 1;
            btnProximaPagina.Enabled = totalItens == _itensPorPagina;

            bool temSelecao = dgvClientes.SelectedRows.Count > 0;
            btnEditar.Enabled = temSelecao;
            btnRemover.Enabled = temSelecao;
        }

        // ============================================
        // EVENTOS DOS BOTÕES
        // ============================================

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            _filtroAtual = txtPesquisa.Text.Trim();
            _paginaAtual = 1;
            CarregarClientes();
        }

        private void txtPesquisa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnPesquisar_Click(sender, e);
                e.Handled = true;
            }
        }

        private void btnNovoCliente_Click(object sender, EventArgs e)
        {
            try
            {
                var formDetalhes = new FormClienteDetalhes();
                var resultado = formDetalhes.ShowDialog();

                if (resultado == DialogResult.OK)
                {
                    CarregarClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir formulário:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            CarregarClientes();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Selecione um cliente para editar.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                var cliente = dgvClientes.SelectedRows[0].Tag as Cliente;

                if (cliente == null)
                {
                    MessageBox.Show(
                        "Erro ao obter dados do cliente selecionado.",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                var formDetalhes = new FormClienteDetalhes(cliente);
                var resultado = formDetalhes.ShowDialog();

                if (resultado == DialogResult.OK)
                {
                    CarregarClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao editar cliente:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (dgvClientes.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Selecione um cliente para remover.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                var cliente = dgvClientes.SelectedRows[0].Tag as Cliente;

                if (cliente == null)
                {
                    MessageBox.Show(
                        "Erro ao obter dados do cliente selecionado.",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                var resultado = MessageBox.Show(
                    $"Deseja realmente remover o cliente?\n\n" +
                    $"Nome: {cliente.Nome}\n" +
                    $"NIF: {cliente.NIF}\n\n" +
                    "Esta ação não pode ser desfeita!",
                    "Confirmar Remoção",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (resultado == DialogResult.Yes)
                {
                    bool sucesso = _repositorio.Remover(cliente.Id);

                    if (sucesso)
                    {
                        MessageBox.Show(
                            "Cliente removido com sucesso!",
                            "Sucesso",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );

                        CarregarClientes();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Cliente não encontrado.",
                            "Erro",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao remover cliente:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // ============================================
        // PAGINAÇÃO
        // ============================================

        private void btnPaginaAnterior_Click(object sender, EventArgs e)
        {
            if (_paginaAtual > 1)
            {
                _paginaAtual--;
                CarregarClientes();
            }
        }

        private void btnProximaPagina_Click(object sender, EventArgs e)
        {
            _paginaAtual++;
            CarregarClientes();
        }

        private void cboItensPorPagina_SelectedIndexChanged(object sender, EventArgs e)
        {
            string textoSelecionado = cboItensPorPagina.SelectedItem.ToString();
            _itensPorPagina = int.Parse(textoSelecionado);
            _paginaAtual = 1;
            CarregarClientes();
        }

        // ============================================
        // EVENTOS DO DATAGRIDVIEW
        // ============================================

        private void dgvClientes_SelectionChanged(object sender, EventArgs e)
        {
            bool temSelecao = dgvClientes.SelectedRows.Count > 0;
            btnEditar.Enabled = temSelecao;
            btnRemover.Enabled = temSelecao;

            if (temSelecao)
            {
                _clienteSelecionado = dgvClientes.SelectedRows[0].Tag as Cliente;
            }
            else
            {
                _clienteSelecionado = null;
            }
        }

        private void dgvClientes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEditar_Click(sender, e);
            }
        }
    }
}