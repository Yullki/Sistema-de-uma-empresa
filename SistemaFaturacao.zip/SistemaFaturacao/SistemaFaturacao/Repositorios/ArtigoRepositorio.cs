﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using SistemaFaturacao.Interfaces;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;
using SistemaFaturacao.Servicos;

namespace SistemaFaturacao.Repositorios
{
    /// <summary>
    /// ============================================
    /// CLASSE: ArtigoRepositorio
    /// ============================================
    /// Implementa operações CRUD para Artigos
    /// 
    /// IMPLEMENTA: IRepositorio<Artigo>
    /// 
    /// RESPONSABILIDADES:
    /// - Inserir artigos no BD
    /// - Atualizar artigos existentes
    /// - Remover artigos (hard delete)
    /// - Consultar artigos (por ID, todos, paginado)
    /// - Registar tempo de execução (usando LoggerServico)
    /// 
    /// PERFORMANCE:
    /// - Usa pool de conexões (ConexaoBD)
    /// - Paginação para grandes volumes
    /// - Índices nas colunas de pesquisa (BD)
    /// - Parâmetros preparados (evita SQL injection)
    /// ============================================
    /// </summary>
    public class ArtigoRepositorio : IRepositorio<Artigo>
    {
        // ============================================
        // CAMPO PRIVADO
        // ============================================

        /// <summary>
        /// Instância do logger para registar tempos
        /// READONLY: definido no construtor
        /// </summary>
        private readonly ILoggerServico _logger;

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Construtor do repositório
        /// Inicializa logger
        /// </summary>
        public ArtigoRepositorio()
        {
            // Obtém instância Singleton do logger
            _logger = LoggerServico.Instancia;
        }

        // ============================================
        // IMPLEMENTAÇÃO: Inserir
        // ============================================

        /// <summary>
        /// Insere novo artigo no banco de dados
        /// 
        /// ALGORITMO:
        /// 1. Valida objeto Artigo
        /// 2. Inicia log de tempo
        /// 3. Abre conexão (do pool)
        /// 4. Prepara comando INSERT
        /// 5. Adiciona parâmetros
        /// 6. Executa INSERT
        /// 7. Obtém ID gerado (LAST_INSERT_ID)
        /// 8. Fecha conexão (devolve ao pool)
        /// 9. Finaliza log de tempo
        /// 10. Retorna ID
        /// 
        /// FLUXO DE EXCEÇÕES:
        /// - ValidacaoException: dados inválidos
        /// - BaseDadosException: erro MySQL (duplicado, constraint)
        /// 
        /// PARÂMETRO: entidade - objeto Artigo preenchido
        /// RETORNO: ID gerado pelo AUTO_INCREMENT
        /// </summary>
        public int Inserir(Artigo entidade)
        {
            // 1. VALIDAÇÃO
            entidade.Validar();

            // 2. INICIA LOG
            var inicio = _logger.IniciarOperacao("Inserir Artigo");

            try
            {
                int novoId = 0;

                // 3. OBTÉM CONEXÃO DO POOL
                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    // 4. DEFINE SQL
                    // @parametro: placeholder para valor (segurança)
                    string sql = @"
                        INSERT INTO Artigos 
                        (CodigoBarras, Nome, Descricao, CategoriaId, PrecoUnitario, 
                         StockAtual, StockMinimo, Ativo, DataCriacao)
                        VALUES 
                        (@CodigoBarras, @Nome, @Descricao, @CategoriaId, @PrecoUnitario,
                         @StockAtual, @StockMinimo, @Ativo, @DataCriacao)";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        // 5. ADICIONA PARÂMETROS
                        // AddWithValue: associa placeholder com valor
                        // Previne SQL Injection!
                        comando.Parameters.AddWithValue("@CodigoBarras", entidade.CodigoBarras);
                        comando.Parameters.AddWithValue("@Nome", entidade.Nome);
                        comando.Parameters.AddWithValue("@Descricao", entidade.Descricao ?? "");
                        comando.Parameters.AddWithValue("@CategoriaId", entidade.CategoriaId);
                        comando.Parameters.AddWithValue("@PrecoUnitario", entidade.PrecoUnitario);
                        comando.Parameters.AddWithValue("@StockAtual", entidade.StockAtual);
                        comando.Parameters.AddWithValue("@StockMinimo", entidade.StockMinimo);
                        comando.Parameters.AddWithValue("@Ativo", entidade.Ativo);
                        comando.Parameters.AddWithValue("@DataCriacao", entidade.DataCriacao);

                        // 6. EXECUTA INSERT
                        comando.ExecuteNonQuery();

                        // 7. OBTÉM ID GERADO
                        // LAST_INSERT_ID(): função MySQL que retorna último ID
                        novoId = (int)comando.LastInsertedId;
                    }
                }

                // 8. FINALIZA LOG
                _logger.FinalizarOperacao(inicio, $"Artigo inserido: {entidade.Nome} (ID: {novoId})");

                // 9. RETORNA ID
                return novoId;
            }
            catch (MySqlException ex)
            {
                // Erro MySQL (ex: código de barras duplicado)
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao inserir artigo: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                // Qualquer outro erro
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro inesperado ao inserir artigo: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: Atualizar
        // ============================================

        /// <summary>
        /// Atualiza artigo existente
        /// 
        /// ALGORITMO:
        /// 1. Valida objeto
        /// 2. Inicia log
        /// 3. Abre conexão
        /// 4. Prepara UPDATE com WHERE Id = @Id
        /// 5. Executa UPDATE
        /// 6. Verifica linhas afetadas (0 = não encontrado)
        /// 7. Finaliza log
        /// 8. Retorna sucesso/falha
        /// 
        /// PARÂMETRO: entidade - Artigo com Id preenchido
        /// RETORNO: true se atualizado, false se não encontrado
        /// </summary>
        public bool Atualizar(Artigo entidade)
        {
            // VALIDAÇÃO
            entidade.Validar();

            if (entidade.Id <= 0)
            {
                throw new ValidacaoException("ID do artigo é obrigatório para atualização.");
            }

            var inicio = _logger.IniciarOperacao("Atualizar Artigo");

            try
            {
                int linhasAfetadas = 0;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    // SQL UPDATE
                    string sql = @"
                        UPDATE Artigos SET
                            CodigoBarras = @CodigoBarras,
                            Nome = @Nome,
                            Descricao = @Descricao,
                            CategoriaId = @CategoriaId,
                            PrecoUnitario = @PrecoUnitario,
                            StockAtual = @StockAtual,
                            StockMinimo = @StockMinimo,
                            Ativo = @Ativo
                        WHERE ArtigoId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        // Parâmetros
                        comando.Parameters.AddWithValue("@Id", entidade.Id);
                        comando.Parameters.AddWithValue("@CodigoBarras", entidade.CodigoBarras);
                        comando.Parameters.AddWithValue("@Nome", entidade.Nome);
                        comando.Parameters.AddWithValue("@Descricao", entidade.Descricao ?? "");
                        comando.Parameters.AddWithValue("@CategoriaId", entidade.CategoriaId);
                        comando.Parameters.AddWithValue("@PrecoUnitario", entidade.PrecoUnitario);
                        comando.Parameters.AddWithValue("@StockAtual", entidade.StockAtual);
                        comando.Parameters.AddWithValue("@StockMinimo", entidade.StockMinimo);
                        comando.Parameters.AddWithValue("@Ativo", entidade.Ativo);

                        // Executa e obtém número de linhas afetadas
                        linhasAfetadas = comando.ExecuteNonQuery();
                    }
                }

                bool sucesso = linhasAfetadas > 0;
                _logger.FinalizarOperacao(inicio,
                    sucesso ? $"Artigo atualizado: {entidade.Nome}" : "Artigo não encontrado");

                return sucesso;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao atualizar artigo: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro inesperado ao atualizar artigo: {ex.Message}", ex);
            }
        }        // ============================================
                 // IMPLEMENTAÇÃO: Remover
                 // ============================================

        /// <summary>
        /// Remove artigo permanentemente (HARD DELETE)
        /// 
        /// ATENÇÃO: Preferir Desativar() para soft delete
        /// 
        /// ALGORITMO:
        /// 1. Valida ID
        /// 2. Inicia log
        /// 3. Executa DELETE FROM Artigos WHERE Id = @Id
        /// 4. Verifica linhas afetadas
        /// 5. Finaliza log
        /// 
        /// PARÂMETRO: id - identificador do artigo
        /// RETORNO: true se removido, false se não encontrado
        /// </summary>
        public bool Remover(int id)
        {
            if (id <= 0)
            {
                throw new ValidacaoException("ID inválido para remoção.");
            }

            var inicio = _logger.IniciarOperacao("Remover Artigo");

            try
            {
                int linhasAfetadas = 0;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = "DELETE FROM Artigos WHERE ArtigoId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Id", id);
                        linhasAfetadas = comando.ExecuteNonQuery();
                    }
                }

                bool sucesso = linhasAfetadas > 0;
                _logger.FinalizarOperacao(inicio,
                    sucesso ? $"Artigo removido (ID: {id})" : "Artigo não encontrado");

                return sucesso;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao remover artigo: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: ObterPorId
        // ============================================

        /// <summary>
        /// Busca artigo específico por ID
        /// 
        /// ALGORITMO:
        /// 1. Valida ID
        /// 2. Inicia log
        /// 3. SELECT com JOIN em Categorias (pegar nome)
        /// 4. ExecuteReader: lê resultado
        /// 5. Se encontrou, converte para objeto Artigo
        /// 6. Se não encontrou, retorna null
        /// 7. Finaliza log
        /// 
        /// PARÂMETRO: id - identificador
        /// RETORNO: objeto Artigo ou null
        /// </summary>
        public Artigo ObterPorId(int id)
        {
            if (id <= 0)
            {
                throw new ValidacaoException("ID inválido.");
            }

            var inicio = _logger.IniciarOperacao("Obter Artigo Por ID");

            try
            {
                Artigo artigo = null;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    // JOIN para pegar nome da categoria
                    string sql = @"
                        SELECT 
                            a.ArtigoId, a.CodigoBarras, a.Nome, a.Descricao,
                            a.CategoriaId, c.Nome AS CategoriaNome,
                            a.PrecoUnitario, a.StockAtual, a.StockMinimo,
                            a.Ativo, a.DataCriacao
                        FROM Artigos a
                        LEFT JOIN Categorias c ON a.CategoriaId = c.CategoriaId
                        WHERE a.ArtigoId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Id", id);

                        // ExecuteReader: usado para SELECT (lê resultados)
                        using (var reader = comando.ExecuteReader())
                        {
                            // Read(): avança para próxima linha (retorna false se fim)
                            if (reader.Read())
                            {
                                // Converte linha do BD para objeto
                                artigo = ConverterReaderParaArtigo(reader);
                            }
                        }
                    }
                }

                _logger.FinalizarOperacao(inicio,
                    artigo != null ? $"Artigo encontrado: {artigo.Nome}" : "Artigo não encontrado");

                return artigo;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar artigo: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: ObterTodos
        // ============================================

        /// <summary>
        /// Obtém todos os artigos ativos
        /// 
        /// ATENÇÃO PERFORMANCE:
        /// Não usar se tiver +1000 artigos!
        /// Usar ObterComPaginacao() em vez disso
        /// 
        /// ALGORITMO:
        /// 1. Inicia log
        /// 2. SELECT * FROM Artigos WHERE Ativo = true
        /// 3. Para cada linha, converter para Artigo
        /// 4. Adicionar à lista
        /// 5. Finaliza log
        /// 
        /// RETORNO: List<Artigo> (pode estar vazia)
        /// </summary>
        public List<Artigo> ObterTodos()
        {
            var inicio = _logger.IniciarOperacao("Obter Todos Artigos");

            try
            {
                var artigos = new List<Artigo>();

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT 
                            a.ArtigoId, a.CodigoBarras, a.Nome, a.Descricao,
                            a.CategoriaId, c.Nome AS CategoriaNome,
                            a.PrecoUnitario, a.StockAtual, a.StockMinimo,
                            a.Ativo, a.DataCriacao
                        FROM Artigos a
                        LEFT JOIN Categorias c ON a.CategoriaId = c.CategoriaId
                        WHERE a.Ativo = true
                        ORDER BY a.Nome";

                    using (var comando = new MySqlCommand(sql, conexao))
                    using (var reader = comando.ExecuteReader())
                    {
                        // CICLO: lê todas as linhas
                        while (reader.Read())
                        {
                            artigos.Add(ConverterReaderParaArtigo(reader));
                        }
                    }
                }

                _logger.FinalizarOperacao(inicio, $"{artigos.Count} artigos carregados");

                return artigos;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar artigos: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: ObterComPaginacao (PERFORMANCE!)
        // ============================================

        /// <summary>
        /// Obtém artigos com paginação e filtro
        /// 
        /// ESSENCIAL PARA +1000 ARTIGOS/UTILIZADORES!
        /// 
        /// ALGORITMO:
        /// 1. Calcula OFFSET: (pagina - 1) * tamanhoPagina
        /// 2. Se filtro fornecido, adiciona WHERE LIKE
        /// 3. SELECT ... LIMIT tamanhoPagina OFFSET calculado
        /// 4. Converte resultados em lista
        /// 
        /// EXEMPLO:
        /// Página 2, 50 itens, filtro "panela"
        /// OFFSET = (2-1) * 50 = 50
        /// SELECT ... WHERE Nome LIKE '%panela%' LIMIT 50 OFFSET 50
        /// Retorna artigos 51-100 que contenham "panela"
        /// 
        /// PARÂMETROS:
        /// - pagina: número da página (começa em 1)
        /// - tamanhoPagina: itens por página (recomendado: 50-100)
        /// - filtro: texto de busca (opcional)
        /// 
        /// RETORNO: List<Artigo> da página solicitada
        /// </summary>
        public List<Artigo> ObterComPaginacao(int pagina, int tamanhoPagina, string filtro = "")
        {
            // VALIDAÇÃO
            if (pagina < 1)
                throw new ValidacaoException("Número de página deve ser >= 1");

            if (tamanhoPagina < 1)
                throw new ValidacaoException("Tamanho de página deve ser >= 1");

            var inicio = _logger.IniciarOperacao("Obter Artigos Paginado");

            try
            {
                var artigos = new List<Artigo>();

                // CÁLCULO DE OFFSET
                int offset = (pagina - 1) * tamanhoPagina;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    // SQL BASE
                    string sql = @"
                        SELECT 
                            a.ArtigoId, a.CodigoBarras, a.Nome, a.Descricao,
                            a.CategoriaId, c.Nome AS CategoriaNome,
                            a.PrecoUnitario, a.StockAtual, a.StockMinimo,
                            a.Ativo, a.DataCriacao
                        FROM Artigos a
                        LEFT JOIN Categorias c ON a.CategoriaId = c.CategoriaId
                        WHERE a.Ativo = true";

                    // ADICIONA FILTRO SE FORNECIDO
                    if (!string.IsNullOrWhiteSpace(filtro))
                    {
                        // LIKE: busca parcial (% = qualquer caractere)
                        // Busca em Nome, Descricao e CodigoBarras
                        sql += @" AND (
                            a.Nome LIKE @Filtro OR 
                            a.Descricao LIKE @Filtro OR 
                            a.CodigoBarras LIKE @Filtro
                        )";
                    }

                    // ADICIONA ORDENAÇÃO E PAGINAÇÃO
                    sql += " ORDER BY a.Nome LIMIT @Limite OFFSET @Offset";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        // PARÂMETROS
                        comando.Parameters.AddWithValue("@Limite", tamanhoPagina);
                        comando.Parameters.AddWithValue("@Offset", offset);

                        if (!string.IsNullOrWhiteSpace(filtro))
                        {
                            // Adiciona % para busca parcial
                            comando.Parameters.AddWithValue("@Filtro", $"%{filtro}%");
                        }

                        // EXECUTA E LÊ RESULTADOS
                        using (var reader = comando.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                artigos.Add(ConverterReaderParaArtigo(reader));
                            }
                        }
                    }
                }

                string detalhes = $"Página {pagina}, {artigos.Count} artigos";
                if (!string.IsNullOrWhiteSpace(filtro))
                    detalhes += $", Filtro: '{filtro}'";

                _logger.FinalizarOperacao(inicio, detalhes);

                return artigos;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar artigos paginados: {ex.Message}", ex);
            }
        }

        // ============================================
        // MÉTODO AUXILIAR PRIVADO
        // ============================================

        /// <summary>
        /// Converte linha do MySqlDataReader para objeto Artigo
        /// 
        /// LÓGICA:
        /// - Lê cada coluna do resultado SQL
        /// - Cria objeto Artigo
        /// - Preenche propriedades
        /// - Trata valores NULL
        /// 
        /// PARÂMETRO: reader - leitor posicionado em uma linha
        /// RETORNO: objeto Artigo preenchido
        /// </summary>
        private Artigo ConverterReaderParaArtigo(MySqlDataReader reader)
        {
            return new Artigo
            {
                // Obter valores das colunas
                // GetInt32(índice): lê coluna como int
                // GetString(índice): lê coluna como string
                // GetDecimal(índice): lê coluna como decimal
                // GetDateTime(índice): lê coluna como DateTime
                // GetBoolean(índice): lê coluna como bool

                Id = reader.GetInt32("ArtigoId"),
                CodigoBarras = reader.GetString("CodigoBarras"),
                Nome = reader.GetString("Nome"),

                // IsDBNull: verifica se valor é NULL no BD
                Descricao = reader.IsDBNull(reader.GetOrdinal("Descricao"))
                    ? ""
                    : reader.GetString("Descricao"),

                CategoriaId = reader.GetInt32("CategoriaId"),

                CategoriaNome = reader.IsDBNull(reader.GetOrdinal("CategoriaNome"))
                    ? "Sem Categoria"
                    : reader.GetString("CategoriaNome"),

                PrecoUnitario = reader.GetDecimal("PrecoUnitario"),
                StockAtual = reader.GetInt32("StockAtual"),
                StockMinimo = reader.GetInt32("StockMinimo"),
                Ativo = reader.GetBoolean("Ativo"),
                DataCriacao = reader.GetDateTime("DataCriacao")
            };
        }
    }
}