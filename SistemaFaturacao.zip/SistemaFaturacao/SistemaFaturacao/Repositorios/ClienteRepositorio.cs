﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using SistemaFaturacao.Interfaces;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;
using SistemaFaturacao.Servicos;

namespace SistemaFaturacao.Repositorios
{
    /// <summary>
    /// ============================================
    /// CLASSE: ClienteRepositorio
    /// ============================================
    /// Implementa operações CRUD para Clientes
    /// 
    /// PADRÃO: Similar ao ArtigoRepositorio
    /// PERFORMANCE: Pool de conexões, paginação, logs
    /// ============================================
    /// </summary>
    public class ClienteRepositorio : IRepositorio<Cliente>
    {
        // ============================================
        // CAMPO PRIVADO
        // ============================================

        private readonly ILoggerServico _logger;

        // ============================================
        // CONSTRUTOR
        // ============================================

        public ClienteRepositorio()
        {
            _logger = LoggerServico.Instancia;
        }

        // ============================================
        // IMPLEMENTAÇÃO: Inserir
        // ============================================

        public int Inserir(Cliente entidade)
        {
            entidade.Validar();

            var inicio = _logger.IniciarOperacao("Inserir Cliente");

            try
            {
                int novoId = 0;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        INSERT INTO Clientes 
                        (NIF, Nome, Email, Telefone, Morada, Ativo)
                        VALUES 
                        (@NIF, @Nome, @Email, @Telefone, @Morada, @Ativo)";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NIF", entidade.NIF);
                        comando.Parameters.AddWithValue("@Nome", entidade.Nome);
                        comando.Parameters.AddWithValue("@Email", entidade.Email ?? "");
                        comando.Parameters.AddWithValue("@Telefone", entidade.Telefone ?? "");
                        comando.Parameters.AddWithValue("@Morada", entidade.Morada ?? "");
                        comando.Parameters.AddWithValue("@Ativo", entidade.Ativo);

                        comando.ExecuteNonQuery();
                        novoId = (int)comando.LastInsertedId;
                    }
                }

                _logger.FinalizarOperacao(inicio, $"Cliente inserido: {entidade.Nome} (ID: {novoId})");
                return novoId;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao inserir cliente: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: Atualizar
        // ============================================

        public bool Atualizar(Cliente entidade)
        {
            entidade.Validar();

            if (entidade.Id <= 0)
            {
                throw new ValidacaoException("ID do cliente é obrigatório para atualização.");
            }

            var inicio = _logger.IniciarOperacao("Atualizar Cliente");

            try
            {
                int linhasAfetadas = 0;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        UPDATE Clientes SET
                            NIF = @NIF,
                            Nome = @Nome,
                            Email = @Email,
                            Telefone = @Telefone,
                            Morada = @Morada,
                            Ativo = @Ativo
                        WHERE ClienteId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Id", entidade.Id);
                        comando.Parameters.AddWithValue("@NIF", entidade.NIF);
                        comando.Parameters.AddWithValue("@Nome", entidade.Nome);
                        comando.Parameters.AddWithValue("@Email", entidade.Email ?? "");
                        comando.Parameters.AddWithValue("@Telefone", entidade.Telefone ?? "");
                        comando.Parameters.AddWithValue("@Morada", entidade.Morada ?? "");
                        comando.Parameters.AddWithValue("@Ativo", entidade.Ativo);

                        linhasAfetadas = comando.ExecuteNonQuery();
                    }
                }

                bool sucesso = linhasAfetadas > 0;
                _logger.FinalizarOperacao(inicio,
                    sucesso ? $"Cliente atualizado: {entidade.Nome}" : "Cliente não encontrado");

                return sucesso;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao atualizar cliente: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: Remover
        // ============================================

        public bool Remover(int id)
        {
            if (id <= 0)
            {
                throw new ValidacaoException("ID inválido para remoção.");
            }

            var inicio = _logger.IniciarOperacao("Remover Cliente");

            try
            {
                int linhasAfetadas = 0;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = "DELETE FROM Clientes WHERE ClienteId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Id", id);
                        linhasAfetadas = comando.ExecuteNonQuery();
                    }
                }

                bool sucesso = linhasAfetadas > 0;
                _logger.FinalizarOperacao(inicio,
                    sucesso ? $"Cliente removido (ID: {id})" : "Cliente não encontrado");

                return sucesso;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao remover cliente: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: ObterPorId
        // ============================================

        public Cliente ObterPorId(int id)
        {
            if (id <= 0)
            {
                throw new ValidacaoException("ID inválido.");
            }

            var inicio = _logger.IniciarOperacao("Obter Cliente Por ID");

            try
            {
                Cliente cliente = null;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT ClienteId, NIF, Nome, Email, Telefone, Morada, Ativo
                        FROM Clientes
                        WHERE ClienteId = @Id";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Id", id);

                        using (var reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                cliente = ConverterReaderParaCliente(reader);
                            }
                        }
                    }
                }

                _logger.FinalizarOperacao(inicio,
                    cliente != null ? $"Cliente encontrado: {cliente.Nome}" : "Cliente não encontrado");

                return cliente;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar cliente: {ex.Message}", ex);
            }
        }        // ============================================
                 // IMPLEMENTAÇÃO: ObterTodos
                 // ============================================

        public List<Cliente> ObterTodos()
        {
            var inicio = _logger.IniciarOperacao("Obter Todos Clientes");

            try
            {
                var clientes = new List<Cliente>();

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT ClienteId, NIF, Nome, Email, Telefone, Morada, Ativo
                        FROM Clientes
                        WHERE Ativo = true
                        ORDER BY Nome";

                    using (var comando = new MySqlCommand(sql, conexao))
                    using (var reader = comando.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            clientes.Add(ConverterReaderParaCliente(reader));
                        }
                    }
                }

                _logger.FinalizarOperacao(inicio, $"{clientes.Count} clientes carregados");
                return clientes;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar clientes: {ex.Message}", ex);
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO: ObterComPaginacao
        // ============================================

        public List<Cliente> ObterComPaginacao(int pagina, int tamanhoPagina, string filtro = "")
        {
            if (pagina < 1)
                throw new ValidacaoException("Número de página deve ser >= 1");

            if (tamanhoPagina < 1)
                throw new ValidacaoException("Tamanho de página deve ser >= 1");

            var inicio = _logger.IniciarOperacao("Obter Clientes Paginado");

            try
            {
                var clientes = new List<Cliente>();
                int offset = (pagina - 1) * tamanhoPagina;

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT ClienteId, NIF, Nome, Email, Telefone, Morada, Ativo
                        FROM Clientes
                        WHERE Ativo = true";

                    if (!string.IsNullOrWhiteSpace(filtro))
                    {
                        sql += @" AND (
                            Nome LIKE @Filtro OR 
                            NIF LIKE @Filtro OR 
                            Email LIKE @Filtro OR
                            Telefone LIKE @Filtro
                        )";
                    }

                    sql += " ORDER BY Nome LIMIT @Limite OFFSET @Offset";

                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@Limite", tamanhoPagina);
                        comando.Parameters.AddWithValue("@Offset", offset);

                        if (!string.IsNullOrWhiteSpace(filtro))
                        {
                            comando.Parameters.AddWithValue("@Filtro", $"%{filtro}%");
                        }

                        using (var reader = comando.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                clientes.Add(ConverterReaderParaCliente(reader));
                            }
                        }
                    }
                }

                string detalhes = $"Página {pagina}, {clientes.Count} clientes";
                if (!string.IsNullOrWhiteSpace(filtro))
                    detalhes += $", Filtro: '{filtro}'";

                _logger.FinalizarOperacao(inicio, detalhes);
                return clientes;
            }
            catch (MySqlException ex)
            {
                _logger.FinalizarOperacao(inicio, $"ERRO: {ex.Message}");
                throw new BaseDadosException($"Erro ao buscar clientes paginados: {ex.Message}", ex);
            }
        }

        // ============================================
        // MÉTODO AUXILIAR PRIVADO
        // ============================================

        private Cliente ConverterReaderParaCliente(MySqlDataReader reader)
        {
            return new Cliente
            {
                Id = reader.GetInt32("ClienteId"),
                NIF = reader.GetString("NIF"),
                Nome = reader.GetString("Nome"),

                Email = reader.IsDBNull(reader.GetOrdinal("Email"))
                    ? ""
                    : reader.GetString("Email"),

                Telefone = reader.IsDBNull(reader.GetOrdinal("Telefone"))
                    ? ""
                    : reader.GetString("Telefone"),

                Morada = reader.IsDBNull(reader.GetOrdinal("Morada"))
                    ? ""
                    : reader.GetString("Morada"),

                Ativo = reader.GetBoolean("Ativo")
            };
        }
    }
}