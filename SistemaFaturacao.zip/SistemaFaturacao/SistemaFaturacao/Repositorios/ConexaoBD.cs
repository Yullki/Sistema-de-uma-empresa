﻿using System;
using System.Configuration;
using MySql.Data.MySqlClient;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao.Repositorios
{
    /// <summary>
    /// ============================================
    /// CLASSE: ConexaoBD
    /// ============================================
    /// Gerencia conexões com MySQL usando POOL DE CONEXÕES
    /// 
    /// PADRÃO: Singleton (única instância)
    /// 
    /// POOL DE CONEXÕES - EXPLICAÇÃO:
    /// 
    /// SEM POOL (lento, problema com +1000 users):
    /// 1. User 1 pede dados → Abre conexão (200ms)
    /// 2. User 1 recebe → Fecha conexão
    /// 3. User 2 pede dados → Abre NOVA conexão (200ms)
    /// Total: muita latência, servidor sobrecarregado
    /// 
    /// COM POOL (rápido, suporta +1000 users):
    /// 1. Pool cria 5-100 conexões mantidas abertas
    /// 2. User 1 pede → Pega conexão do pool (0ms)
    /// 3. User 1 termina → Devolve ao pool (não fecha!)
    /// 4. User 2 pede → Reutiliza mesma conexão (0ms)
    /// Total: rápido, eficiente, escalável
    /// 
    /// CONFIGURAÇÃO NO App.config:
    /// - Pooling=true (ativa pool)
    /// - MinPoolSize=5 (mínimo de conexões mantidas)
    /// - MaxPoolSize=100 (máximo simultâneo)
    /// ============================================
    /// </summary>
    public class ConexaoBD
    {
        // ============================================
        // SINGLETON: Instância única
        // ============================================

        /// <summary>
        /// Instância única da classe (Singleton Pattern)
        /// STATIC: compartilhada por toda aplicação
        /// VOLATILE: garante thread-safety em multi-threading
        /// PRIVATE: só acessível internamente
        /// </summary>
        private static volatile ConexaoBD _instancia;

        /// <summary>
        /// Objeto para sincronização de threads
        /// LOCK: garante que apenas 1 thread crie instância
        /// READONLY: não pode ser alterado após inicialização
        /// </summary>
        private static readonly object _lock = new object();

        /// <summary>
        /// String de conexão lida do App.config
        /// PRIVATE: encapsulamento
        /// READONLY: definida uma vez no construtor
        /// </summary>
        private readonly string _connectionString;

        // ============================================
        // CONSTRUTOR PRIVADO (Singleton)
        // ============================================

        /// <summary>
        /// Construtor privado - impede new ConexaoBD() externo
        /// 
        /// FLUXO:
        /// 1. Lê connectionString do App.config
        /// 2. Valida se existe
        /// 3. Armazena em _connectionString
        /// 
        /// EXCEÇÃO: Se não encontrar configuração
        /// </summary>
        private ConexaoBD()
        {
            // Busca string de conexão no App.config
            // Nome: "MySqlConnection" (definido no App.config)
            var connectionStringConfig = ConfigurationManager.ConnectionStrings["MySqlConnection"];

            // ESTRUTURA CONDICIONAL: verifica se existe
            if (connectionStringConfig == null || string.IsNullOrEmpty(connectionStringConfig.ConnectionString))
            {
                // Lança exceção se não configurado
                throw new BaseDadosException(
                    "String de conexão 'MySqlConnection' não encontrada no App.config. " +
                    "Verifique se o arquivo está configurado corretamente."
                );
            }

            // Armazena string para uso posterior
            _connectionString = connectionStringConfig.ConnectionString;
        }

        // ============================================
        // PROPRIEDADE: Obter Instância (Singleton)
        // ============================================

        /// <summary>
        /// Obtém a instância única da classe (Singleton)
        /// 
        /// ALGORITMO DOUBLE-CHECK LOCKING (thread-safe):
        /// 1. Verifica se _instancia é null (rápido, sem lock)
        /// 2. Se null, entra em região protegida (lock)
        /// 3. Verifica novamente (double-check)
        /// 4. Se ainda null, cria instância
        /// 5. Retorna instância
        /// 
        /// THREAD-SAFETY:
        /// Múltiplas threads podem chamar simultaneamente
        /// Lock garante que apenas 1 cria a instância
        /// 
        /// RETORNO: instância única de ConexaoBD
        /// </summary>
        public static ConexaoBD Instancia
        {
            get
            {
                // PRIMEIRA VERIFICAÇÃO (sem lock - performance)
                if (_instancia == null)
                {
                    // LOCK: bloqueia outras threads
                    lock (_lock)
                    {
                        // SEGUNDA VERIFICAÇÃO (dentro do lock)
                        // Necessário porque outra thread pode ter criado
                        // entre a primeira verificação e o lock
                        if (_instancia == null)
                        {
                            // Cria instância única
                            _instancia = new ConexaoBD();
                        }
                    }
                }

                // Retorna instância (criada ou existente)
                return _instancia;
            }
        }

        // ============================================
        // MÉTODO: Obter Conexão do Pool
        // ============================================

        /// <summary>
        /// Cria e retorna conexão MySQL (do pool)
        /// 
        /// IMPORTANTE: SEMPRE usar com using()!
        /// 
        /// FLUXO:
        /// 1. Cria objeto MySqlConnection
        /// 2. Abre conexão (pega do pool se disponível)
        /// 3. Retorna conexão aberta
        /// 
        /// POOL DE CONEXÕES (automático):
        /// - MySqlConnection detecta Pooling=true na string
        /// - Tenta pegar conexão aberta do pool
        /// - Se pool vazio, cria nova (até MaxPoolSize)
        /// - Se pool cheio, aguarda conexão disponível (timeout)
        /// 
        /// USO CORRETO:
        /// using (var conexao = ConexaoBD.Instancia.ObterConexao())
        /// {
        ///     // usar conexão
        /// } // Fecha automaticamente e DEVOLVE ao pool
        /// 
        /// RETORNO: MySqlConnection aberta
        /// EXCEÇÕES: BancoDadosException se falhar
        /// </summary>
        public MySqlConnection ObterConexao()
        {
            try
            {
                // Cria nova conexão MySQL com string configurada
                var conexao = new MySqlConnection(_connectionString);

                // ABRE CONEXÃO
                // Se pool ativo: pega do pool (rápido)
                // Se pool inativo: cria nova (lento)
                conexao.Open();

                // Retorna conexão pronta para uso
                return conexao;
            }
            catch (MySqlException ex)
            {
                // Captura erros MySQL específicos
                // Exemplos: servidor offline, senha errada, timeout
                throw new BaseDadosException(
                    $"Erro ao conectar com MySQL: {ex.Message}", ex
                );
            }
            catch (Exception ex)
            {
                // Captura outros erros inesperados
                throw new BaseDadosException(
                    $"Erro inesperado ao obter conexão: {ex.Message}", ex
                );
            }
        }

        // ============================================
        // MÉTODO: Testar Conexão
        // ============================================

        /// <summary>
        /// Testa se consegue conectar ao MySQL
        /// 
        /// USO: verificar configuração, diagnóstico
        /// 
        /// FLUXO:
        /// 1. Tenta obter conexão
        /// 2. Se sucesso, fecha e retorna true
        /// 3. Se falha, retorna false
        /// 
        /// RETORNO: true se conectou, false se falhou
        /// </summary>
        public bool TestarConexao()
        {
            try
            {
                // Tenta obter conexão
                // using: garante fechamento automático
                using (var conexao = ObterConexao())
                {
                    // Se chegou aqui, conexão OK
                    return true;
                }
            }
            catch
            {
                // Qualquer erro = falha na conexão
                return false;
            }
        }
    }
}