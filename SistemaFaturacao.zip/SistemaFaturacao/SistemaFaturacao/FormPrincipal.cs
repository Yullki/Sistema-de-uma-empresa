﻿using System;
using System.Windows.Forms;

namespace SistemaFaturacao
{
    /// <summary>
    /// ============================================
    /// FORMULÁRIO PRINCIPAL
    /// ============================================
    /// Menu principal do sistema
    /// 
    /// DESIGN:
    /// - Botões grandes e coloridos (usabilidade)
    /// - Poucos cliques para qualquer ação
    /// - Visual limpo e profissional
    /// 
    /// NAVEGAÇÃO:
    /// - Cada botão abre formulário específico
    /// - FormPrincipal permanece aberto (MDI ou ShowDialog)
    /// ============================================
    /// </summary>
    public partial class FormPrincipal : Form
    {
        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Inicializa o formulário principal
        /// </summary>
        public FormPrincipal()
        {
            InitializeComponent();

            // Define título da janela
            this.Text = "Sistema de Faturação - Armazenista";
        }

        // ============================================
        // EVENTOS DOS BOTÕES
        // ============================================

        /// <summary>
        /// Abre formulário de gestão de artigos
        /// ATALHO: F2
        /// </summary>
        private void btnGestaoArtigos_Click(object sender, EventArgs e)
        {
            try
            {
                // Cria instância do formulário de artigos
                var formArtigos = new FormListagemArtigos();

                // Abre como modal (bloqueia FormPrincipal até fechar)
                formArtigos.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir gestão de artigos:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Abre formulário de gestão de clientes
        /// </summary>
        private void btnGestaoClientes_Click(object sender, EventArgs e)
        {
            try
            {
                var formClientes = new FormListagemClientes();
                formClientes.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir gestão de clientes:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Abre formulário de criação de faturas
        /// </summary>
        private void btnCriarFatura_Click(object sender, EventArgs e)
        {
            try
            {
                var formFatura = new FormNovaFatura();
                formFatura.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir criação de fatura:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }


        /// <summary>
        /// Abre formulário de relatórios e logs
        /// </summary>
        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            try
            {
                var formRelatorios = new FormRelatorios();
                formRelatorios.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao abrir relatórios:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
        // ============================================
        // EVENTOS DO FORMULÁRIO
        // ============================================

        /// <summary>
        /// Evento disparado ao carregar o formulário
        /// FLUXO:
        /// 1. Testa conexão com BD
        /// 2. Se falhar, exibe erro e fecha aplicação
        /// </summary>
        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // Testa conexão ao iniciar
                var conexao = Repositorios.ConexaoBD.Instancia;
                if (!conexao.TestarConexao())
                {
                    MessageBox.Show(
                        "Não foi possível conectar à base de dados.\n\n" +
                        "Verifique:\n" +
                        "• MySQL está em execução\n" +
                        "• Configurações no App.config\n" +
                        "• Base de dados 'SistemaFaturacao' existe",
                        "Erro de Conexão",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );

                    // Fecha aplicação se não conectar
                    Application.Exit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao iniciar aplicação:\n\n{ex.Message}",
                    "Erro Crítico",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                Application.Exit();
            }
        }

        /// <summary>
        /// Confirma saída da aplicação
        /// </summary>
        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            var resultado = MessageBox.Show(
                "Deseja realmente sair do sistema?",
                "Confirmar Saída",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.No)
            {
                e.Cancel = true; // Cancela fechamento
            }
        }

        private void btnTesteCarga_Click(object sender, EventArgs e)
        {
            var formTeste = new FormTesteCarga();
            formTeste.ShowDialog();
        }
    }
}