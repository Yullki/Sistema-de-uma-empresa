﻿using System;
using System.Drawing;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao
{
    /// <summary>
    /// FormClienteDetalhes SIMPLIFICADO
    /// Apenas: Nome, Telefone, Email
    /// </summary>
    public partial class FormClienteDetalhes : Form
    {
        private readonly ClienteRepositorio _repositorio;
        private readonly bool _modoInsercao;
        private Cliente _clienteEmEdicao;

        // Construtor INSERT
        public FormClienteDetalhes()
        {
            InitializeComponent();
            _repositorio = new ClienteRepositorio();
            _modoInsercao = true;
            _clienteEmEdicao = null;
            lblTitulo.Text = "Novo Cliente";
        }

        // Construtor UPDATE
        public FormClienteDetalhes(Cliente cliente)
        {
            InitializeComponent();
            _repositorio = new ClienteRepositorio();
            _modoInsercao = false;
            _clienteEmEdicao = cliente;
            lblTitulo.Text = "Editar Cliente";
        }

        private void FormClienteDetalhes_Load(object sender, EventArgs e)
        {
            if (!_modoInsercao && _clienteEmEdicao != null)
            {
                txtNomeCompleto.Text = _clienteEmEdicao.Nome;
                txtTelefoneCliente.Text = _clienteEmEdicao.Telefone;
                txtEmail.Text = _clienteEmEdicao.Email;
            }
            txtNomeCompleto.Focus();
        }

        private bool ValidarCampos()
        {
            bool valido = true;

            // Nome obrigatório
            if (string.IsNullOrWhiteSpace(txtNomeCompleto.Text))
            {
                txtNomeCompleto.BackColor = Color.LightCoral;
                valido = false;
            }
            else
            {
                txtNomeCompleto.BackColor = Color.White;
            }

            // Telefone obrigatório
            if (string.IsNullOrWhiteSpace(txtTelefoneCliente.Text))
            {
                txtTelefoneCliente.BackColor = Color.LightCoral;
                valido = false;
            }
            else
            {
                txtTelefoneCliente.BackColor = Color.White;
            }

            // Email opcional, mas se preenchido valida formato
            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                if (!txtEmail.Text.Contains("@"))
                {
                    txtEmail.BackColor = Color.LightCoral;
                    valido = false;
                }
                else
                {
                    txtEmail.BackColor = Color.White;
                }
            }
            else
            {
                txtEmail.BackColor = Color.White;
            }

            return valido;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidarCampos())
                {
                    MessageBox.Show(
                        "Preencha os campos obrigatórios.",
                        "Validação",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                Cliente cliente;

                if (_modoInsercao)
                {
                    cliente = new Cliente();
                    // Gera NIF automático (simplificado: timestamp)
                    cliente.NIF = DateTime.Now.ToString("yyMMddHHmmss").Substring(0, 9);
                }
                else
                {
                    cliente = _clienteEmEdicao;
                }

                cliente.Nome = txtNomeCompleto.Text.Trim();
                cliente.Telefone = txtTelefoneCliente.Text.Trim();
                cliente.Email = txtEmail.Text.Trim();
                cliente.Ativo = true;

                if (_modoInsercao)
                {
                    int novoId = _repositorio.Inserir(cliente);
                    MessageBox.Show(
                        $"Cliente inserido!\n\nNome: {cliente.Nome}",
                        "Sucesso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    _repositorio.Atualizar(cliente);
                    MessageBox.Show(
                        "Cliente atualizado!",
                        "Sucesso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro: {ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void txtNomeCompleto_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNomeCompleto.Text))
                txtNomeCompleto.BackColor = Color.LightCoral;
            else
                txtNomeCompleto.BackColor = Color.White;
        }

        private void txtTelefoneCliente_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTelefoneCliente.Text))
                txtTelefoneCliente.BackColor = Color.LightCoral;
            else
                txtTelefoneCliente.BackColor = Color.White;
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtEmail.Text) && !txtEmail.Text.Contains("@"))
                txtEmail.BackColor = Color.LightCoral;
            else
                txtEmail.BackColor = Color.White;
        }
    }
}