﻿using System;

namespace SistemaFaturacao.Interfaces
{
    /// <summary>
    /// ============================================
    /// INTERFACE: ILoggerServico
    /// ============================================
    /// Define contrato para logging de operações
    /// 
    /// OBJETIVO: Registar tempo de execução de operações
    /// 
    /// REQUISITO DO PROJETO:
    /// "tempo de execução de operações (cada operação 
    /// mais importante aparecer um log texto com o tempo 
    /// de execução: datahora início, datahora fim, 
    /// tempo execução em segundos)"
    /// 
    /// USO:
    /// var inicio = logger.IniciarOperacao("Inserir Artigo");
    /// // ... código da operação ...
    /// logger.FinalizarOperacao(inicio, "Artigo inserido com sucesso");
    /// ============================================
    /// </summary>
    public interface ILoggerServico
    {
        /// <summary>
        /// Inicia o registo de uma operação
        /// 
        /// PARÂMETRO: nomeOperacao - nome descritivo
        /// RETORNO: DateTime de início (para calcular duração)
        /// 
        /// EXEMPLO:
        /// var inicio = logger.IniciarOperacao("Carregar 1000 Artigos");
        /// </summary>
        DateTime IniciarOperacao(string nomeOperacao);

        /// <summary>
        /// Finaliza e grava log da operação
        /// 
        /// PARÂMETROS:
        /// - dataHoraInicio: retornado por IniciarOperacao()
        /// - detalhes: informação adicional (opcional)
        /// 
        /// FLUXO:
        /// 1. Captura dataHoraFim = DateTime.Now
        /// 2. Calcula tempo = (fim - inicio).TotalSeconds
        /// 3. Grava na tabela LogsOperacoes
        /// 
        /// EXEMPLO:
        /// logger.FinalizarOperacao(inicio, "1000 artigos carregados");
        /// </summary>
        void FinalizarOperacao(DateTime dataHoraInicio, string detalhes = "");
    }
}