﻿using System;
using System.Collections.Generic;
using SistemaFaturacao.Models.Abstratas;

namespace SistemaFaturacao.Interfaces
{
    /// <summary>
    /// ============================================
    /// INTERFACE GENÉRICA: IRepositorio<T>
    /// ============================================
    /// Define contrato para operações CRUD (Create, Read, Update, Delete)
    /// 
    /// PADRÃO DE PROJETO: Repository Pattern
    /// 
    /// BENEFÍCIOS:
    /// - Abstrai acesso a dados (pode trocar MySQL por outro BD)
    /// - Facilita testes unitários (mock da interface)
    /// - Código desacoplado (ServicoBD não depende de implementação)
    /// - Reutilização (mesma interface para todas entidades)
    /// 
    /// GENÉRICO <T>:
    /// T pode ser Artigo, Cliente, Fatura, etc.
    /// RESTRIÇÃO: T deve herdar de EntidadeBase
    /// 
    /// CONVENÇÃO:
    /// - Interface começa com I (IRepositorio)
    /// - Métodos em PascalCase
    /// - Parâmetros em camelCase
    /// ============================================
    /// </summary>
    /// <typeparam name="T">Tipo da entidade (deve herdar EntidadeBase)</typeparam>
    public interface IRepositorio<T> where T : EntidadeBase
    {
        // ============================================
        // OPERAÇÃO: CREATE (Inserir)
        // ============================================

        /// <summary>
        /// Insere nova entidade no banco de dados
        /// 
        /// FLUXO:
        /// 1. Recebe objeto preenchido
        /// 2. Valida dados
        /// 3. Executa INSERT no MySQL
        /// 4. Retorna ID gerado (AUTO_INCREMENT)
        /// 
        /// PARÂMETRO: entidade - objeto a ser inserido
        /// RETORNO: ID gerado pelo banco (int)
        /// EXCEÇÕES: ValidacaoException, BancoDadosException
        /// 
        /// EXEMPLO DE USO:
        /// var artigo = new Artigo { Nome = "Panela", ... };
        /// int novoId = repositorio.Inserir(artigo);
        /// </summary>
        int Inserir(T entidade);

        // ============================================
        // OPERAÇÃO: UPDATE (Atualizar)
        // ============================================

        /// <summary>
        /// Atualiza entidade existente no banco
        /// 
        /// FLUXO:
        /// 1. Recebe objeto com Id preenchido
        /// 2. Valida se existe no BD
        /// 3. Executa UPDATE
        /// 4. Retorna sucesso/falha
        /// 
        /// PARÂMETRO: entidade - objeto com dados atualizados
        /// RETORNO: true se atualizado, false se não encontrado
        /// EXCEÇÕES: ValidacaoException, BancoDadosException
        /// </summary>
        bool Atualizar(T entidade);

        // ============================================
        // OPERAÇÃO: DELETE (Remover)
        // ============================================

        /// <summary>
        /// Remove permanentemente do banco (HARD DELETE)
        /// 
        /// ATENÇÃO: Use Desativar() para SOFT DELETE (preferível)
        /// 
        /// FLUXO:
        /// 1. Recebe ID
        /// 2. Executa DELETE FROM tabela WHERE id = ...
        /// 3. Retorna sucesso/falha
        /// 
        /// PARÂMETRO: id - identificador da entidade
        /// RETORNO: true se removido, false se não encontrado
        /// </summary>
        bool Remover(int id);

        // ============================================
        // OPERAÇÃO: READ - Por ID
        // ============================================

        /// <summary>
        /// Busca entidade específica por ID
        /// 
        /// FLUXO:
        /// 1. Recebe ID
        /// 2. Executa SELECT * FROM tabela WHERE id = ...
        /// 3. Converte resultado em objeto
        /// 4. Retorna objeto ou null
        /// 
        /// PARÂMETRO: id - identificador
        /// RETORNO: objeto T ou null se não encontrado
        /// 
        /// EXEMPLO:
        /// var artigo = repositorio.ObterPorId(5);
        /// if (artigo != null) { ... }
        /// </summary>
        T ObterPorId(int id);

        // ============================================
        // OPERAÇÃO: READ - Todos
        // ============================================

        /// <summary>
        /// Obtém todas as entidades ativas
        /// 
        /// FLUXO:
        /// 1. Executa SELECT * FROM tabela WHERE Ativo = true
        /// 2. Converte resultados em lista
        /// 3. Retorna lista (pode ser vazia)
        /// 
        /// ATENÇÃO PERFORMANCE:
        /// - Para +1000 registros, usar ObterComPaginacao()
        /// - Esta função carrega TUDO na memória
        /// 
        /// RETORNO: List<T> (lista pode estar vazia)
        /// </summary>
        List<T> ObterTodos();

        // ============================================
        // OPERAÇÃO: READ - Paginado (PERFORMANCE!)
        // ============================================

        /// <summary>
        /// Obtém entidades com paginação e filtro
        /// 
        /// ESSENCIAL PARA PERFORMANCE!
        /// Requisito: suportar +1000 utilizadores/produtos
        /// 
        /// ALGORITMO:
        /// 1. Calcula OFFSET: (pagina - 1) * tamanhoPagina
        /// 2. Aplica filtro opcional (LIKE %filtro%)
        /// 3. Executa: SELECT ... LIMIT tamanhoPagina OFFSET calculado
        /// 4. Retorna apenas registros da página
        /// 
        /// PARÂMETROS:
        /// - pagina: número da página (começa em 1)
        /// - tamanhoPagina: quantos registros por página (ex: 50)
        /// - filtro: texto para busca (opcional, "" = sem filtro)
        /// 
        /// RETORNO: List<T> com registros da página
        /// 
        /// EXEMPLO:
        /// // Página 2, 50 itens, buscar "panela"
        /// var artigos = repositorio.ObterComPaginacao(2, 50, "panela");
        /// // Retorna artigos 51-100 que contenham "panela" no nome
        /// </summary>
        List<T> ObterComPaginacao(int pagina, int tamanhoPagina, string filtro = "");
    }
}