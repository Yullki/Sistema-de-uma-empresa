﻿namespace SistemaFaturacao
{
    partial class FormTesteCarga
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbInformacoesBasicas = new System.Windows.Forms.GroupBox();
            this.btnIniciarTeste = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cboOperacao = new System.Windows.Forms.ComboBox();
            this.nudUsuarios = new System.Windows.Forms.NumericUpDown();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTelefoneCliente = new System.Windows.Forms.TextBox();
            this.txtTelefone = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtLog = new System.Windows.Forms.RichTextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.gbInformacoesBasicas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudUsuarios)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbInformacoesBasicas
            // 
            this.gbInformacoesBasicas.Controls.Add(this.btnIniciarTeste);
            this.gbInformacoesBasicas.Controls.Add(this.label3);
            this.gbInformacoesBasicas.Controls.Add(this.cboOperacao);
            this.gbInformacoesBasicas.Controls.Add(this.nudUsuarios);
            this.gbInformacoesBasicas.Controls.Add(this.txtEmail);
            this.gbInformacoesBasicas.Controls.Add(this.label7);
            this.gbInformacoesBasicas.Controls.Add(this.txtTelefoneCliente);
            this.gbInformacoesBasicas.Controls.Add(this.txtTelefone);
            this.gbInformacoesBasicas.Controls.Add(this.label2);
            this.gbInformacoesBasicas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbInformacoesBasicas.Location = new System.Drawing.Point(20, 60);
            this.gbInformacoesBasicas.Name = "gbInformacoesBasicas";
            this.gbInformacoesBasicas.Size = new System.Drawing.Size(640, 120);
            this.gbInformacoesBasicas.TabIndex = 23;
            this.gbInformacoesBasicas.TabStop = false;
            this.gbInformacoesBasicas.Text = "Configuração do Teste";
            // 
            // btnIniciarTeste
            // 
            this.btnIniciarTeste.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnIniciarTeste.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIniciarTeste.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIniciarTeste.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciarTeste.ForeColor = System.Drawing.Color.White;
            this.btnIniciarTeste.Location = new System.Drawing.Point(483, 28);
            this.btnIniciarTeste.Name = "btnIniciarTeste";
            this.btnIniciarTeste.Size = new System.Drawing.Size(150, 60);
            this.btnIniciarTeste.TabIndex = 29;
            this.btnIniciarTeste.Text = "Iniciar Teste";
            this.btnIniciarTeste.UseVisualStyleBackColor = false;
            this.btnIniciarTeste.Click += new System.EventHandler(this.btnIniciarTeste_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 23);
            this.label3.TabIndex = 28;
            this.label3.Text = "Operação a Testar:";
            // 
            // cboOperacao
            // 
            this.cboOperacao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOperacao.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboOperacao.FormattingEnabled = true;
            this.cboOperacao.Items.AddRange(new object[] {
            "Carregar Artigos",
            "Carregar Clientes",
            "Inserir Artigo (teste)",
            "Consulta Simples"});
            this.cboOperacao.Location = new System.Drawing.Point(177, 65);
            this.cboOperacao.Name = "cboOperacao";
            this.cboOperacao.Size = new System.Drawing.Size(300, 33);
            this.cboOperacao.TabIndex = 25;
            // 
            // nudUsuarios
            // 
            this.nudUsuarios.Location = new System.Drawing.Point(333, 28);
            this.nudUsuarios.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.nudUsuarios.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudUsuarios.Name = "nudUsuarios";
            this.nudUsuarios.Size = new System.Drawing.Size(121, 30);
            this.nudUsuarios.TabIndex = 27;
            this.nudUsuarios.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudUsuarios.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(7, 227);
            this.txtEmail.MaxLength = 150;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(250, 31);
            this.txtEmail.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "Email: ";
            // 
            // txtTelefoneCliente
            // 
            this.txtTelefoneCliente.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefoneCliente.Location = new System.Drawing.Point(7, 143);
            this.txtTelefoneCliente.MaxLength = 20;
            this.txtTelefoneCliente.Name = "txtTelefoneCliente";
            this.txtTelefoneCliente.Size = new System.Drawing.Size(490, 31);
            this.txtTelefoneCliente.TabIndex = 5;
            // 
            // txtTelefone
            // 
            this.txtTelefone.AutoSize = true;
            this.txtTelefone.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefone.Location = new System.Drawing.Point(10, 117);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(89, 23);
            this.txtTelefone.TabIndex = 4;
            this.txtTelefone.Text = "Telefone: *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(293, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Número de Utilizadores Simultâneos:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(576, 31);
            this.label1.TabIndex = 22;
            this.label1.Text = "Teste de Carga - Simulação de Múltiplos Utilizadores";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtLog);
            this.groupBox1.Controls.Add(this.progressBar);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(20, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(640, 250);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Resultados";
            // 
            // txtLog
            // 
            this.txtLog.BackColor = System.Drawing.Color.Black;
            this.txtLog.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLog.ForeColor = System.Drawing.Color.LimeGreen;
            this.txtLog.Location = new System.Drawing.Point(20, 30);
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(600, 180);
            this.txtLog.TabIndex = 7;
            this.txtLog.Text = "";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(20, 220);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(600, 20);
            this.progressBar.TabIndex = 6;
            // 
            // FormTesteCarga
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(682, 453);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbInformacoesBasicas);
            this.Controls.Add(this.label1);
            this.Name = "FormTesteCarga";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teste de Carga - Pool de Conexões";
            this.Load += new System.EventHandler(this.FormTesteCarga_Load);
            this.gbInformacoesBasicas.ResumeLayout(false);
            this.gbInformacoesBasicas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudUsuarios)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbInformacoesBasicas;
        private System.Windows.Forms.ComboBox cboOperacao;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTelefoneCliente;
        private System.Windows.Forms.Label txtTelefone;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudUsuarios;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnIniciarTeste;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.RichTextBox txtLog;
    }
}