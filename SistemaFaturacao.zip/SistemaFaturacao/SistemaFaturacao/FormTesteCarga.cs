﻿using MySql.Data.MySqlClient;
using SistemaFaturacao.Models;
using SistemaFaturacao.Repositorios;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFaturacao
{
    /// <summary>
    /// Teste de carga MELHORADO
    /// Mostra diferença COM e SEM pool
    /// </summary>
    public partial class FormTesteCarga : Form
    {
        public FormTesteCarga()
        {
            InitializeComponent();
        }

        private void FormTesteCarga_Load(object sender, EventArgs e)
        {
            cboOperacao.SelectedIndex = 0;
            AdicionarLog("Sistema pronto para teste de carga.");
            AdicionarLog($"Pool atual: Min=5, Max=100");
            AdicionarLog("");
            AdicionarLog("💡 DICA: Teste com 200+ utilizadores para saturar o pool");
        }

        private async void btnIniciarTeste_Click(object sender, EventArgs e)
        {
            try
            {
                btnIniciarTeste.Enabled = false;
                txtLog.Clear();

                int numUsuarios = (int)nudUsuarios.Value;
                string operacao = cboOperacao.SelectedItem.ToString();

                AdicionarLog($"═══════════════════════════════════════");
                AdicionarLog($"TESTE DE CARGA - POOL DE CONEXÕES");
                AdicionarLog($"═══════════════════════════════════════");
                AdicionarLog($"Utilizadores: {numUsuarios}");
                AdicionarLog($"Operação: {operacao}");
                AdicionarLog($"Pool: Min=5, Max=100");
                AdicionarLog($"");

                if (numUsuarios > 100)
                {
                    AdicionarLog($"⚠️ ATENÇÃO: {numUsuarios} users > 100 (MaxPoolSize)", Color.Yellow);
                    AdicionarLog($"   Alguns ficarão em fila de espera!", Color.Yellow);
                    AdicionarLog($"");
                }

                progressBar.Maximum = numUsuarios;
                progressBar.Value = 0;

                var stopwatch = Stopwatch.StartNew();
                var tasks = new List<Task>();
                var temposIndividuais = new List<double>();
                var erros = new List<string>();
                var timeouts = 0;

                // Contador de conexões ativas (simulado)
                int conexoesAtivas = 0;
                int picoConexoes = 0;
                object lockObj = new object();

                for (int i = 0; i < numUsuarios; i++)
                {
                    int userId = i + 1;

                    var task = Task.Run(() =>
                    {
                        var sw = Stopwatch.StartNew();

                        try
                        {
                            // Incrementa contador de conexões ativas
                            lock (lockObj)
                            {
                                conexoesAtivas++;
                                if (conexoesAtivas > picoConexoes)
                                    picoConexoes = conexoesAtivas;
                            }

                            // Executa operação
                            switch (operacao)
                            {
                                case "Carregar Artigos":
                                    ExecutarCarregarArtigos();
                                    break;

                                case "Carregar Clientes":
                                    ExecutarCarregarClientes();
                                    break;

                                case "Inserir Artigo (teste)":
                                    ExecutarInserirArtigoTeste(userId);
                                    break;

                                case "Consulta Simples":
                                    ExecutarConsultaSimples();
                                    break;

                                case "Operação Lenta (5s)":
                                    ExecutarOperacaoLenta();
                                    break;
                            }

                            sw.Stop();

                            lock (temposIndividuais)
                            {
                                temposIndividuais.Add(sw.Elapsed.TotalMilliseconds);
                            }
                        }
                        catch (MySqlException ex)
                        {
                            if (ex.Message.Contains("Timeout") || ex.Message.Contains("timeout"))
                            {
                                lock (lockObj)
                                {
                                    timeouts++;
                                }
                            }

                            lock (erros)
                            {
                                erros.Add($"User {userId}: {ex.Message}");
                            }
                        }
                        catch (Exception ex)
                        {
                            lock (erros)
                            {
                                erros.Add($"User {userId}: {ex.Message}");
                            }
                        }
                        finally
                        {
                            // Decrementa contador
                            lock (lockObj)
                            {
                                conexoesAtivas--;
                            }

                            this.Invoke((Action)(() => { progressBar.Value++; }));
                        }
                    });

                    tasks.Add(task);

                    // Pequeno delay para não iniciar TODAS ao exato mesmo tempo
                    // (mais realista)
                    if (i % 10 == 0)
                        await Task.Delay(5);
                }

                await Task.WhenAll(tasks);
                stopwatch.Stop();

                // RESULTADOS
                AdicionarLog($"═══════════════════════════════════════");
                AdicionarLog($"RESULTADOS DO TESTE");
                AdicionarLog($"═══════════════════════════════════════");
                AdicionarLog($"Tempo total: {stopwatch.Elapsed.TotalSeconds:F3}s");
                AdicionarLog($"Sucesso: {temposIndividuais.Count}/{numUsuarios}");
                AdicionarLog($"Erros: {erros.Count}");
                AdicionarLog($"Timeouts: {timeouts}");
                AdicionarLog($"Pico de conexões simultâneas: {picoConexoes}");
                AdicionarLog($"");

                if (temposIndividuais.Count > 0)
                {
                    double media = temposIndividuais.Average();
                    double minimo = temposIndividuais.Min();
                    double maximo = temposIndividuais.Max();

                    AdicionarLog($"Tempo médio: {media:F3}ms");
                    AdicionarLog($"Mais rápida: {minimo:F3}ms");
                    AdicionarLog($"Mais lenta: {maximo:F3}ms");
                    AdicionarLog($"");

                    // ANÁLISE
                    AdicionarLog($"ANÁLISE DE PERFORMANCE:");

                    if (timeouts > 0)
                    {
                        AdicionarLog($"❌ {timeouts} timeouts! Pool saturado.", Color.Red);
                        AdicionarLog($"   Solução: Aumentar MaxPoolSize para {picoConexoes + 50}", Color.Yellow);
                    }
                    else if (erros.Count > numUsuarios * 0.1)
                    {
                        AdicionarLog($"⚠️ Muitos erros ({erros.Count}). Verificar configuração.", Color.Orange);
                    }
                    else if (picoConexoes >= 90)
                    {
                        AdicionarLog($"⚠️ Pool quase saturado ({picoConexoes}/100).", Color.Yellow);
                        AdicionarLog($"   Considere aumentar MaxPoolSize para {picoConexoes + 50}", Color.Yellow);
                    }
                    else
                    {
                        AdicionarLog($"✅ EXCELENTE! Pool dimensionado corretamente.", Color.LimeGreen);
                        AdicionarLog($"   Pico: {picoConexoes}/100 conexões ({picoConexoes}%)", Color.LimeGreen);
                    }

                    // Estimativa SEM pool
                    double tempoSemPool = numUsuarios * 200; // 200ms por conexão
                    double ganhoPool = tempoSemPool / stopwatch.Elapsed.TotalMilliseconds;

                    AdicionarLog($"");
                    AdicionarLog($"COMPARAÇÃO:");
                    AdicionarLog($"  Com Pool: {stopwatch.Elapsed.TotalSeconds:F3}s");
                    AdicionarLog($"  Sem Pool (estimado): {tempoSemPool / 1000:F3}s");
                    AdicionarLog($"  Ganho: {ganhoPool:F1}x mais rápido", Color.LimeGreen);
                }

                if (erros.Count > 0)
                {
                    AdicionarLog($"");
                    AdicionarLog($"ERROS ({erros.Count}):", Color.Red);
                    for (int i = 0; i < Math.Min(5, erros.Count); i++)
                    {
                        AdicionarLog($"  {erros[i]}", Color.Red);
                    }
                    if (erros.Count > 5)
                        AdicionarLog($"  ... e mais {erros.Count - 5} erros", Color.Red);
                }

                btnIniciarTeste.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIniciarTeste.Enabled = true;
            }
        }

        // ============================================
        // OPERAÇÕES DE TESTE (MAIS REALISTAS)
        // ============================================

        private void ExecutarCarregarArtigos()
        {
            var repo = new ArtigoRepositorio();
            var artigos = repo.ObterComPaginacao(1, 50);

            // Simula processamento
            Thread.Sleep(10);
        }

        private void ExecutarCarregarClientes()
        {
            var repo = new ClienteRepositorio();
            var clientes = repo.ObterComPaginacao(1, 50);

            Thread.Sleep(10);
        }

        private void ExecutarInserirArtigoTeste(int userId)
        {
            var repo = new ArtigoRepositorio();
            var artigo = new Artigo
            {
                CodigoBarras = $"TEST{DateTime.Now.Ticks}{userId}",
                Nome = $"Teste Carga User {userId}",
                Descricao = "Teste de carga",
                CategoriaId = 1,
                PrecoUnitario = 10.00m,
                StockAtual = 100,
                StockMinimo = 10
            };
            repo.Inserir(artigo);
        }

        private void ExecutarConsultaSimples()
        {
            using (var conexao = ConexaoBD.Instancia.ObterConexao())
            {
                using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM Artigos", conexao))
                {
                    cmd.ExecuteScalar();
                }
            }

            // Simula processamento (mais realista)
            Thread.Sleep(5);
        }

        private void AdicionarLog(string mensagem, Color? cor = null)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke((Action)(() => AdicionarLog(mensagem, cor)));
                return;
            }

            txtLog.SelectionStart = txtLog.TextLength;
            txtLog.SelectionLength = 0;
            txtLog.SelectionColor = cor ?? Color.LimeGreen;
            txtLog.AppendText($"{DateTime.Now:HH:mm:ss.fff} - {mensagem}\r\n");
            txtLog.SelectionColor = txtLog.ForeColor;
            txtLog.ScrollToCaret();
        }

        private void ExecutarOperacaoLenta()
        {
            using (var conexao = ConexaoBD.Instancia.ObterConexao())
            {
                using (var cmd = new MySqlCommand("SELECT SLEEP(5)", conexao))
                {
                    cmd.ExecuteScalar(); // Dorme 5 segundos!
                }
            }
        }
    }
}