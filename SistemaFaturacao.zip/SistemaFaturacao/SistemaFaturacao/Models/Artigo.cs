﻿using System;
using SistemaFaturacao.Models.Abstratas;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao.Models
{
    /// <summary>
    /// ============================================
    /// CLASSE: Artigo
    /// ============================================
    /// Representa um artigo de cozinha no sistema
    /// 
    /// HERANÇA: EntidadeBase (herda Id, Ativo, Validar)
    /// 
    /// PROPRIEDADES:
    /// - CodigoBarras: identificação única (EAN-13)
    /// - Nome: nome do artigo
    /// - Descricao: descrição detalhada
    /// - CategoriaId: FK para tabela Categorias
    /// - PrecoUnitario: preço de venda
    /// - StockAtual: quantidade em stock
    /// - StockMinimo: alerta de reposição
    /// - DataCriacao: quando foi criado
    /// 
    /// CONVENÇÃO:
    /// - Propriedades: PascalCase
    /// - Campos privados: _camelCase (se houver)
    /// ============================================
    /// </summary>
    public class Artigo : EntidadeBase
    {
        // ============================================
        // PROPRIEDADES AUTOMÁTICAS
        // ============================================

        /// <summary>
        /// Código de barras único do artigo (EAN-13)
        /// REGRA: obrigatório, único no sistema
        /// EXEMPLO: "7891234560001"
        /// </summary>
        public string CodigoBarras { get; set; }

        /// <summary>
        /// Nome do artigo
        /// REGRA: obrigatório, mínimo 3 caracteres
        /// EXEMPLO: "Panela Antiaderente 24cm"
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Descrição detalhada do artigo
        /// REGRA: opcional
        /// EXEMPLO: "Panela antiaderente com tampa de vidro"
        /// </summary>
        public string Descricao { get; set; }

        /// <summary>
        /// ID da categoria (FK)
        /// REGRA: obrigatório, deve existir em Categorias
        /// EXEMPLO: 1 (Panelas)
        /// </summary>
        public int CategoriaId { get; set; }

        /// <summary>
        /// Preço unitário de venda
        /// REGRA: obrigatório, deve ser > 0
        /// TIPO: decimal (precisão monetária)
        /// EXEMPLO: 45.90
        /// </summary>
        public decimal PrecoUnitario { get; set; }

        /// <summary>
        /// Quantidade atual em stock
        /// REGRA: não pode ser negativo
        /// PADRÃO: 0
        /// </summary>
        public int StockAtual { get; set; }

        /// <summary>
        /// Stock mínimo antes de alerta
        /// REGRA: não pode ser negativo
        /// PADRÃO: 0
        /// USO: avisar quando StockAtual <= StockMinimo
        /// </summary>
        public int StockMinimo { get; set; }

        /// <summary>
        /// Data e hora de criação do artigo
        /// PREENCHIMENTO: automático ao inserir
        /// </summary>
        public DateTime DataCriacao { get; set; }

        // ============================================
        // PROPRIEDADES AUXILIARES (não vão para BD)
        // ============================================

        /// <summary>
        /// Nome da categoria (carregado via JOIN)
        /// NÃO É COLUNA DO BD - apenas para exibição
        /// </summary>
        public string CategoriaNome { get; set; }

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Construtor padrão
        /// INICIALIZAÇÃO:
        /// - Ativo = true (herdado de EntidadeBase)
        /// - StockAtual = 0
        /// - StockMinimo = 0
        /// - DataCriacao = DateTime.Now
        /// </summary>
        public Artigo()
        {
            // Construtor base já define Ativo = true
            StockAtual = 0;
            StockMinimo = 0;
            DataCriacao = DateTime.Now;
        }

        // ============================================
        // MÉTODO ABSTRATO IMPLEMENTADO
        // ============================================

        /// <summary>
        /// Valida os dados do artigo
        /// IMPLEMENTAÇÃO OBRIGATÓRIA (método abstrato da base)
        /// 
        /// REGRAS DE VALIDAÇÃO:
        /// 1. CodigoBarras: não vazio
        /// 2. Nome: não vazio, mínimo 3 caracteres
        /// 3. CategoriaId: maior que 0
        /// 4. PrecoUnitario: maior que 0
        /// 5. StockAtual: não negativo
        /// 6. StockMinimo: não negativo
        /// 
        /// FLUXO:
        /// 1. Verifica cada regra
        /// 2. Se falhar, lança ValidacaoException com mensagem clara
        /// 3. Se tudo OK, retorna true
        /// 
        /// RETORNO: true se válido
        /// EXCEÇÃO: ValidacaoException se inválido
        /// </summary>
        public override bool Validar()
        {
            // VALIDAÇÃO 1: Código de Barras
            if (string.IsNullOrWhiteSpace(CodigoBarras))
            {
                throw new ValidacaoException("Código de barras é obrigatório.");
            }

            // VALIDAÇÃO 2: Nome (vazio)
            if (string.IsNullOrWhiteSpace(Nome))
            {
                throw new ValidacaoException("Nome do artigo é obrigatório.");
            }

            // VALIDAÇÃO 3: Nome (tamanho mínimo)
            if (Nome.Length < 3)
            {
                throw new ValidacaoException("Nome deve ter no mínimo 3 caracteres.");
            }

            // VALIDAÇÃO 4: Categoria
            if (CategoriaId <= 0)
            {
                throw new ValidacaoException("Categoria é obrigatória.");
            }

            // VALIDAÇÃO 5: Preço
            if (PrecoUnitario <= 0)
            {
                throw new ValidacaoException("Preço unitário deve ser maior que zero.");
            }

            // VALIDAÇÃO 6: Stock Atual
            if (StockAtual < 0)
            {
                throw new ValidacaoException("Stock atual não pode ser negativo.");
            }

            // VALIDAÇÃO 7: Stock Mínimo
            if (StockMinimo < 0)
            {
                throw new ValidacaoException("Stock mínimo não pode ser negativo.");
            }

            // Todas validações passaram
            return true;
        }

        // ============================================
        // MÉTODOS AUXILIARES
        // ============================================

        /// <summary>
        /// Verifica se artigo precisa reposição
        /// LÓGICA: StockAtual <= StockMinimo
        /// 
        /// RETORNO: true se precisa repor
        /// 
        /// USO:
        /// if (artigo.PrecisaReposicao()) {
        ///     // alertar utilizador
        /// }
        /// </summary>
        public bool PrecisaReposicao()
        {
            return StockAtual <= StockMinimo;
        }

        /// <summary>
        /// Adiciona quantidade ao stock
        /// PARÂMETRO: quantidade - quantos itens adicionar
        /// 
        /// FLUXO:
        /// 1. Valida quantidade > 0
        /// 2. Incrementa StockAtual
        /// </summary>
        public void AdicionarStock(int quantidade)
        {
            if (quantidade <= 0)
            {
                throw new ValidacaoException("Quantidade a adicionar deve ser maior que zero.");
            }

            StockAtual += quantidade;
        }

        /// <summary>
        /// Remove quantidade do stock (para vendas)
        /// PARÂMETRO: quantidade - quantos itens remover
        /// 
        /// FLUXO:
        /// 1. Valida quantidade > 0
        /// 2. Verifica se tem stock suficiente
        /// 3. Decrementa StockAtual
        /// 
        /// EXCEÇÃO: NegocioException se stock insuficiente
        /// </summary>
        public void RemoverStock(int quantidade)
        {
            if (quantidade <= 0)
            {
                throw new ValidacaoException("Quantidade a remover deve ser maior que zero.");
            }

            if (quantidade > StockAtual)
            {
                throw new NegocioException(
                    $"Stock insuficiente. Disponível: {StockAtual}, Solicitado: {quantidade}"
                );
            }

            StockAtual -= quantidade;
        }

        /// <summary>
        /// Representação em string do artigo
        /// OVERRIDE: sobrescreve ToString() da base
        /// 
        /// RETORNO: descrição formatada
        /// USO: debugging, logs, ComboBox
        /// </summary>
        public override string ToString()
        {
            return $"{CodigoBarras} - {Nome} (Stock: {StockAtual})";
        }
    }
}