﻿using System;
using SistemaFaturacao.Models.Abstratas;

namespace SistemaFaturacao.Models
{
    /// <summary>
    /// ============================================
    /// CLASSE: LogOperacao
    /// ============================================
    /// Representa um registo de tempo de execução
    /// 
    /// TABELA BD: LogsOperacoes
    /// 
    /// OBJETIVO:
    /// Monitorizar performance e identificar operações lentas
    /// 
    /// EXEMPLO DE REGISTO:
    /// Operacao: "Carregar 1000 Artigos"
    /// DataHoraInicio: 2024-01-15 10:30:00
    /// DataHoraFim: 2024-01-15 10:30:02
    /// TempoExecucaoSegundos: 2.145
    /// Detalhes: "Paginação: página 1, 1000 registos"
    /// ============================================
    /// </summary>
    public class LogOperacao : EntidadeBase
    {
        // ============================================
        // PROPRIEDADES
        // ============================================

        /// <summary>
        /// Nome descritivo da operação
        /// EXEMPLO: "Inserir Artigo", "Pesquisar Cliente"
        /// </summary>
        public string Operacao { get; set; }

        /// <summary>
        /// Data e hora de início da operação
        /// CAPTURA: DateTime.Now ao iniciar
        /// </summary>
        public DateTime DataHoraInicio { get; set; }

        /// <summary>
        /// Data e hora de fim da operação
        /// CAPTURA: DateTime.Now ao finalizar
        /// </summary>
        public DateTime DataHoraFim { get; set; }

        /// <summary>
        /// Tempo total de execução em segundos
        /// CÁLCULO: (DataHoraFim - DataHoraInicio).TotalSeconds
        /// TIPO: decimal para precisão (ex: 2.145 segundos)
        /// </summary>
        public decimal TempoExecucaoSegundos { get; set; }

        /// <summary>
        /// Informações adicionais sobre a operação
        /// OPCIONAL: detalhes, resultados, erros
        /// EXEMPLO: "500 artigos carregados", "Filtro: panela"
        /// </summary>
        public string Detalhes { get; set; }

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Construtor padrão
        /// Inicializa com estado Ativo (herdado)
        /// </summary>
        public LogOperacao()
        {
            // Construtor base define Ativo = true
        }

        // ============================================
        // MÉTODO ABSTRATO IMPLEMENTADO
        // ============================================

        /// <summary>
        /// Valida os dados do log
        /// 
        /// REGRAS:
        /// 1. Operacao não pode estar vazia
        /// 2. DataHoraFim deve ser >= DataHoraInicio
        /// 3. TempoExecucaoSegundos não pode ser negativo
        /// 
        /// RETORNO: true se válido
        /// EXCEÇÃO: ValidacaoException se inválido
        /// </summary>
        public override bool Validar()
        {
            // VALIDAÇÃO 1: Nome da operação
            if (string.IsNullOrWhiteSpace(Operacao))
            {
                throw new Excecoes.ValidacaoException(
                    "Nome da operação é obrigatório."
                );
            }

            // VALIDAÇÃO 2: Datas coerentes
            if (DataHoraFim < DataHoraInicio)
            {
                throw new Excecoes.ValidacaoException(
                    "Data de fim não pode ser anterior à data de início."
                );
            }

            // VALIDAÇÃO 3: Tempo não negativo
            if (TempoExecucaoSegundos < 0)
            {
                throw new Excecoes.ValidacaoException(
                    "Tempo de execução não pode ser negativo."
                );
            }

            return true;
        }

        // ============================================
        // MÉTODOS AUXILIARES
        // ============================================

        /// <summary>
        /// Calcula tempo de execução automaticamente
        /// LÓGICA: Diferença entre fim e início
        /// 
        /// USO:
        /// log.DataHoraInicio = inicio;
        /// log.DataHoraFim = DateTime.Now;
        /// log.CalcularTempo();
        /// </summary>
        public void CalcularTempo()
        {
            // TimeSpan: representa intervalo de tempo
            TimeSpan duracao = DataHoraFim - DataHoraInicio;

            // Converte para decimal (segundos com casas decimais)
            TempoExecucaoSegundos = (decimal)duracao.TotalSeconds;
        }

        /// <summary>
        /// Retorna representação formatada do log
        /// 
        /// FORMATO:
        /// "[Operacao] - Tempo: X.XXs"
        /// 
        /// EXEMPLO:
        /// "[Inserir Artigo] - Tempo: 0.125s"
        /// </summary>
        public override string ToString()
        {
            return $"[{Operacao}] - Tempo: {TempoExecucaoSegundos:F3}s";
        }
    }
}