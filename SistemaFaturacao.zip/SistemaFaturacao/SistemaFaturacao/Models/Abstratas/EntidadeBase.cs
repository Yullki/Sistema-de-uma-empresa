﻿using System;

namespace SistemaFaturacao.Models.Abstratas
{
    /// <summary>
    /// ============================================
    /// CLASSE ABSTRATA BASE
    /// ============================================
    /// Classe base para todas as entidades do sistema.
    /// Fornece propriedades e comportamentos comuns.
    /// 
    /// CONCEITOS POO APLICADOS:
    /// - Abstração: não pode ser instanciada diretamente
    /// - Herança: outras classes herdam dela
    /// - Encapsulamento: propriedades controladas
    /// - Polimorfismo: métodos podem ser sobrescritos
    /// 
    /// CONVENÇÃO DE NOMES:
    /// - Classe: PascalCase (EntidadeBase)
    /// - Propriedades: PascalCase (Id, Ativo)
    /// - Métodos: PascalCase (Validar, Ativar)
    /// ============================================
    /// </summary>
    public abstract class EntidadeBase
    {
        // ============================================
        // PROPRIEDADES
        // ============================================

        /// <summary>
        /// Identificador único da entidade no banco de dados
        /// TIPO: int (número inteiro)
        /// USO: chave primária (PRIMARY KEY)
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Indica se a entidade está ativa no sistema
        /// TIPO: bool (verdadeiro/falso)
        /// USO: soft delete (não apaga do BD, apenas marca como inativo)
        /// PADRÃO: true (ativo ao criar)
        /// </summary>
        public bool Ativo { get; set; }

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Construtor protegido - só classes derivadas podem chamar
        /// LÓGICA: Inicializa entidade com Ativo = true por padrão
        /// FLUXO: Toda nova entidade começa ativa
        /// </summary>
        protected EntidadeBase()
        {
            // Define Ativo como verdadeiro ao criar objeto
            Ativo = true;
        }

        // ============================================
        // MÉTODOS ABSTRATOS
        // ============================================

        /// <summary>
        /// Método abstrato para validação da entidade
        /// ABSTRACT: força classes derivadas a implementarem
        /// RETORNO: true se válido, false se inválido
        /// OBJETIVO: cada entidade tem suas próprias regras
        /// 
        /// EXEMPLOS DE USO:
        /// - Artigo: validar se preço > 0, nome não vazio
        /// - Cliente: validar NIF, email válido
        /// </summary>
        public abstract bool Validar();

        // ============================================
        // MÉTODOS VIRTUAIS (podem ser sobrescritos)
        // ============================================

        /// <summary>
        /// Desativa logicamente a entidade
        /// VIRTUAL: pode ser sobrescrito nas classes derivadas
        /// LÓGICA: Marca Ativo = false (não remove do BD)
        /// BENEFÍCIO: mantém histórico e integridade referencial
        /// 
        /// FLUXO DE EXECUÇÃO:
        /// 1. Método é chamado
        /// 2. Ativo recebe false
        /// 3. Entidade continua no BD mas "invisível"
        /// </summary>
        public virtual void Desativar()
        {
            Ativo = false;
        }

        /// <summary>
        /// Reativa uma entidade previamente desativada
        /// LÓGICA: Marca Ativo = true
        /// USO: recuperar entidade desativada por engano
        /// </summary>
        public virtual void Ativar()
        {
            Ativo = true;
        }

        /// <summary>
        /// Retorna representação em string da entidade
        /// OVERRIDE: sobrescreve método ToString() do Object
        /// RETORNO: descrição básica da entidade
        /// USO: debugging, logs, interface
        /// </summary>
        public override string ToString()
        {
            // Interpolação de string: $"texto {variavel}"
            return $"Entidade ID: {Id}, Ativo: {Ativo}";
        }
    }
}