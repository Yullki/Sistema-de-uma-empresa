﻿using System;
using SistemaFaturacao.Models.Abstratas;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao.Models
{
    /// <summary>
    /// ============================================
    /// CLASSE: Cliente
    /// ============================================
    /// Representa um cliente no sistema
    /// 
    /// HERANÇA: EntidadeBase (Id, Ativo, Validar)
    /// 
    /// PROPRIEDADES:
    /// - NIF: identificação fiscal única (gerado automaticamente)
    /// - Nome: nome completo
    /// - Email: endereço de e-mail
    /// - Telefone: número de telefone
    /// - Morada: endereço completo (não utilizado na versão simplificada)
    /// ============================================
    /// </summary>
    public class Cliente : EntidadeBase
    {
        // ============================================
        // PROPRIEDADES
        // ============================================

        /// <summary>
        /// Número de Identificação Fiscal (NIF)
        /// REGRA: obrigatório, único no sistema
        /// FORMATO: 9 dígitos (Portugal)
        /// NOTA: Gerado automaticamente se não fornecido
        /// </summary>
        public string NIF { get; set; }

        /// <summary>
        /// Nome completo do cliente
        /// REGRA: obrigatório, mínimo 3 caracteres
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Endereço de e-mail
        /// REGRA: opcional, mas se preenchido deve ser válido
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Número de telefone
        /// REGRA: obrigatório na versão simplificada
        /// FORMATO: pode incluir código de país
        /// </summary>
        public string Telefone { get; set; }

        /// <summary>
        /// Morada completa do cliente
        /// REGRA: opcional (não utilizado na interface simplificada)
        /// </summary>
        public string Morada { get; set; }

        // ============================================
        // CONSTRUTOR
        // ============================================

        /// <summary>
        /// Construtor padrão
        /// Inicializa Ativo = true (herdado)
        /// </summary>
        public Cliente()
        {
            // Construtor base define Ativo = true
        }

        // ============================================
        // MÉTODO ABSTRATO IMPLEMENTADO (SIMPLIFICADO)
        // ============================================

        /// <summary>
        /// Valida os dados do cliente - VERSÃO SIMPLIFICADA
        /// 
        /// REGRAS DE VALIDAÇÃO:
        /// 1. Nome: obrigatório
        /// 2. NIF: gerado automaticamente se não existir
        /// 
        /// ALGORITMO:
        /// - Valida nome não vazio
        /// - Se NIF vazio, gera automaticamente (timestamp)
        /// 
        /// RETORNO: true se válido
        /// EXCEÇÃO: ValidacaoException se inválido
        /// </summary>
        public override bool Validar()
        {
            // VALIDAÇÃO 1: Nome obrigatório
            if (string.IsNullOrWhiteSpace(Nome))
            {
                throw new ValidacaoException("Nome é obrigatório.");
            }

            // VALIDAÇÃO 2: Nome tamanho mínimo
            if (Nome.Length < 3)
            {
                throw new ValidacaoException("Nome deve ter no mínimo 3 caracteres.");
            }

            // GERAÇÃO AUTOMÁTICA DE NIF (se não fornecido)
            // Utiliza timestamp para garantir unicidade
            // Formato: YYMMDDHHmmss (últimos 9 dígitos)
            if (string.IsNullOrWhiteSpace(NIF))
            {
                NIF = DateTime.Now.ToString("yyMMddHHmmss").Substring(0, 9);
            }

            // VALIDAÇÃO 3: Email (opcional, mas se preenchido valida formato básico)
            if (!string.IsNullOrWhiteSpace(Email))
            {
                if (!Email.Contains("@") || !Email.Contains("."))
                {
                    throw new ValidacaoException("Email inválido.");
                }
            }

            return true;
        }

        // ============================================
        // MÉTODOS AUXILIARES
        // ============================================

        /// <summary>
        /// Retorna representação em string do cliente
        /// FORMATO: "NIF - Nome"
        /// USO: debugging, logs, ComboBox
        /// 
        /// EXEMPLO:
        /// "240115103045 - João Silva"
        /// </summary>
        public override string ToString()
        {
            return $"{NIF} - {Nome}";
        }
    }
}