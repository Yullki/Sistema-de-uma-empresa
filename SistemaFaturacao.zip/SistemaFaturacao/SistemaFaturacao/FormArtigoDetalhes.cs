﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;
using SistemaFaturacao.Excecoes;
using MySql.Data.MySqlClient;

namespace SistemaFaturacao
{
    /// <summary>
    /// ============================================
    /// FORMULÁRIO: FormArtigoDetalhes
    /// ============================================
    /// Formulário para inserir/editar artigos
    /// 
    /// MODOS DE OPERAÇÃO:
    /// - INSERT: novo artigo (construtor sem parâmetro)
    /// - UPDATE: editar artigo existente (construtor com Artigo)
    /// 
    /// VALIDAÇÕES:
    /// - Campos obrigatórios destacados em vermelho
    /// - Validação em tempo real
    /// - Feedback visual imediato
    /// 
    /// USABILIDADE:
    /// - Enter avança para próximo campo
    /// - Esc cancela
    /// - Ctrl+S salva
    /// ============================================
    /// </summary>
    public partial class FormArtigoDetalhes : Form
    {
        // ============================================
        // CAMPOS PRIVADOS
        // ============================================

        /// <summary>
        /// Repositório para operações CRUD
        /// </summary>
        private readonly ArtigoRepositorio _repositorio;

        /// <summary>
        /// Modo de operação (true = INSERT, false = UPDATE)
        /// </summary>
        private readonly bool _modoInsercao;

        /// <summary>
        /// Artigo sendo editado (null se modo INSERT)
        /// </summary>
        private Artigo _artigoEmEdicao;

        /// <summary>
        /// Lista de categorias disponíveis
        /// </summary>
        private List<Categoria> _categorias;

        // ============================================
        // CONSTRUTORES
        // ============================================

        /// <summary>
        /// Construtor para MODO INSERT (novo artigo)
        /// </summary>
        public FormArtigoDetalhes()
        {
            InitializeComponent();

            _repositorio = new ArtigoRepositorio();
            _modoInsercao = true;
            _artigoEmEdicao = null;

            // Título para inserção
            lblTitulo.Text = "Novo Artigo";
        }

        /// <summary>
        /// Construtor para MODO UPDATE (editar artigo)
        /// PARÂMETRO: artigo - objeto a ser editado
        /// </summary>
        public FormArtigoDetalhes(Artigo artigo)
        {
            InitializeComponent();

            _repositorio = new ArtigoRepositorio();
            _modoInsercao = false;
            _artigoEmEdicao = artigo;

            // Título para edição
            lblTitulo.Text = "Editar Artigo";
        }

        // ============================================
        // EVENTO LOAD
        // ============================================

        /// <summary>
        /// Evento ao carregar o formulário
        /// 
        /// FLUXO:
        /// 1. Carrega categorias no ComboBox
        /// 2. Se modo UPDATE, preenche campos com dados
        /// 3. Configura validações visuais
        /// 4. Define foco no primeiro campo
        /// </summary>
        private void FormArtigoDetalhes_Load(object sender, EventArgs e)
        {
            try
            {
                // Carrega categorias
                CarregarCategorias();

                // Se modo UPDATE, preenche campos
                if (!_modoInsercao && _artigoEmEdicao != null)
                {
                    PreencherCampos();
                }

                // Foco no primeiro campo
                txtCodigoBarras.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao inicializar formulário:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                this.Close();
            }
        }

        // ============================================
        // CARREGAR CATEGORIAS
        // ============================================

        /// <summary>
        /// Carrega categorias do banco de dados
        /// 
        /// FLUXO:
        /// 1. Consulta tabela Categorias
        /// 2. Preenche ComboBox
        /// 3. Define categoria padrão
        /// 
        /// NOTA: Criamos uma classe auxiliar Categoria aqui mesmo
        /// para simplificar (sem criar arquivo separado)
        /// </summary>
        private void CarregarCategorias()
        {
            _categorias = new List<Categoria>();

            try
            {
                using (var conexao = Repositorios.ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT CategoriaId, Nome 
                        FROM Categorias 
                        WHERE Ativo = true 
                        ORDER BY Nome";

                    using (var comando = new MySqlCommand(sql, conexao))
                    using (var reader = comando.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _categorias.Add(new Categoria
                            {
                                Id = reader.GetInt32("CategoriaId"),
                                Nome = reader.GetString("Nome")
                            });
                        }
                    }
                }

                // Preenche ComboBox
                cboCategoria.DataSource = _categorias;
                cboCategoria.DisplayMember = "Nome";
                cboCategoria.ValueMember = "Id";

                // Seleciona primeira categoria
                if (_categorias.Count > 0)
                {
                    cboCategoria.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                throw new BaseDadosException(
                    $"Erro ao carregar categorias: {ex.Message}", ex
                );
            }
        }

        // ============================================
        // PREENCHER CAMPOS (MODO UPDATE)
        // ============================================

        /// <summary>
        /// Preenche campos com dados do artigo em edição
        /// 
        /// FLUXO:
        /// 1. Copia dados do _artigoEmEdicao para os controles
        /// 2. Seleciona categoria correta no ComboBox
        /// 3. Define estado do CheckBox
        /// </summary>
        private void PreencherCampos()
        {
            txtCodigoBarras.Text = _artigoEmEdicao.CodigoBarras;
            txtNome.Text = _artigoEmEdicao.Nome;

            // Seleciona categoria
            cboCategoria.SelectedValue = _artigoEmEdicao.CategoriaId;

            txtPreco.Text = _artigoEmEdicao.PrecoUnitario.ToString("F2");
            nudStockAtual.Value = _artigoEmEdicao.StockAtual;
            nudStockMinimo.Value = _artigoEmEdicao.StockMinimo;
            chkAtivo.Checked = _artigoEmEdicao.Ativo;
        }

        // ============================================
        // VALIDAÇÕES
        // ============================================

        /// <summary>
        /// Valida todos os campos do formulário
        /// 
        /// REGRAS:
        /// - Código de Barras: obrigatório
        /// - Nome: obrigatório, mínimo 3 caracteres
        /// - Categoria: obrigatória
        /// - Preço: obrigatório, maior que zero
        /// 
        /// FEEDBACK VISUAL:
        /// - Campo válido: BackColor branco
        /// - Campo inválido: BackColor vermelho claro
        /// 
        /// RETORNO: true se todos válidos, false se algum inválido
        /// </summary>
        private bool ValidarCampos()
        {
            bool todosValidos = true;

            // VALIDAÇÃO: Código de Barras
            if (string.IsNullOrWhiteSpace(txtCodigoBarras.Text))
            {
                DestacaCampoInvalido(txtCodigoBarras);
                todosValidos = false;
            }
            else
            {
                DestacaCampoValido(txtCodigoBarras);
            }

            // VALIDAÇÃO: Nome
            if (string.IsNullOrWhiteSpace(txtNome.Text) || txtNome.Text.Length < 3)
            {
                DestacaCampoInvalido(txtNome);
                todosValidos = false;
            }
            else
            {
                DestacaCampoValido(txtNome);
            }

            // VALIDAÇÃO: Categoria
            if (cboCategoria.SelectedIndex < 0)
            {
                DestacaCampoInvalido(cboCategoria);
                todosValidos = false;
            }
            else
            {
                DestacaCampoValido(cboCategoria);
            }

            // VALIDAÇÃO: Preço
            if (!decimal.TryParse(txtPreco.Text, out decimal preco) || preco <= 0)
            {
                DestacaCampoInvalido(txtPreco);
                todosValidos = false;
            }
            else
            {
                DestacaCampoValido(txtPreco);
            }

            return todosValidos;
        }

        /// <summary>
        /// Destaca campo inválido (fundo vermelho claro)
        /// </summary>
        private void DestacaCampoInvalido(Control campo)
        {
            campo.BackColor = Color.LightCoral;
        }

        /// <summary>
        /// Restaura campo válido (fundo branco)
        /// </summary>
        private void DestacaCampoValido(Control campo)
        {
            campo.BackColor = Color.White;
        }

        // ============================================
        // EVENTOS DOS BOTÕES
        // ============================================

        /// <summary>
        /// Evento: Botão Salvar
        /// 
        /// FLUXO:
        /// 1. Valida campos
        /// 2. Cria/atualiza objeto Artigo
        /// 3. Chama repositório (Inserir ou Atualizar)
        /// 4. Exibe mensagem de sucesso
        /// 5. Fecha formulário com DialogResult.OK
        /// 
        /// ESTRUTURA TRY-CATCH:
        /// Captura exceções específicas e exibe mensagens claras
        /// </summary>
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. VALIDAÇÃO
                if (!ValidarCampos())
                {
                    MessageBox.Show(
                        "Por favor, corrija os campos destacados em vermelho.",
                        "Validação",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                // 2. CRIA OU ATUALIZA OBJETO
                Artigo artigo;

                if (_modoInsercao)
                {
                    // MODO INSERT: cria novo artigo
                    artigo = new Artigo();
                }
                else
                {
                    // MODO UPDATE: usa artigo existente
                    artigo = _artigoEmEdicao;
                }

                // Preenche propriedades
                artigo.CodigoBarras = txtCodigoBarras.Text.Trim();
                artigo.Nome = txtNome.Text.Trim();
                artigo.CategoriaId = (int)cboCategoria.SelectedValue;
                artigo.PrecoUnitario = decimal.Parse(txtPreco.Text);
                artigo.StockAtual = (int)nudStockAtual.Value;
                artigo.StockMinimo = (int)nudStockMinimo.Value;
                artigo.Ativo = chkAtivo.Checked;

                // 3. CHAMA REPOSITÓRIO
                if (_modoInsercao)
                {
                    // INSERT
                    int novoId = _repositorio.Inserir(artigo);

                    MessageBox.Show(
                        $"Artigo inserido com sucesso!\n\nID: {novoId}\nNome: {artigo.Nome}",
                        "Sucesso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    // UPDATE
                    bool sucesso = _repositorio.Atualizar(artigo);

                    if (sucesso)
                    {
                        MessageBox.Show(
                            $"Artigo atualizado com sucesso!\n\nNome: {artigo.Nome}",
                            "Sucesso",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                    else
                    {
                        throw new BaseDadosException("Artigo não encontrado para atualização.");
                    }
                }

                // 4. FECHA FORMULÁRIO COM SUCESSO
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (ValidacaoException ex)
            {
                MessageBox.Show(
                    $"Erro de validação:\n\n{ex.Message}",
                    "Validação",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
            catch (BaseDadosException ex)
            {
                MessageBox.Show(
                    $"Erro na base de dados:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro inesperado:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Evento: Botão Cancelar
        /// Fecha formulário sem salvar
        /// </summary>
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show(
                "Deseja cancelar? As alterações não serão salvas.",
                "Confirmar Cancelamento",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }        // ============================================
                 // EVENTOS DE VALIDAÇÃO EM TEMPO REAL
                 // ============================================

        /// <summary>
        /// Valida Código de Barras ao sair do campo
        /// </summary>
        private void txtCodigoBarras_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigoBarras.Text))
            {
                DestacaCampoInvalido(txtCodigoBarras);
            }
            else
            {
                DestacaCampoValido(txtCodigoBarras);
            }
        }

        /// <summary>
        /// Valida Nome ao sair do campo
        /// </summary>
        private void txtNome_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) || txtNome.Text.Length < 3)
            {
                DestacaCampoInvalido(txtNome);
            }
            else
            {
                DestacaCampoValido(txtNome);
            }
        }

        /// <summary>
        /// Valida Preço ao sair do campo
        /// </summary>
        private void txtPreco_Leave(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtPreco.Text, out decimal preco) || preco <= 0)
            {
                DestacaCampoInvalido(txtPreco);
            }
            else
            {
                DestacaCampoValido(txtPreco);
            }
        }

        // ============================================
        // ATALHOS DE TECLADO
        // ============================================

        /// <summary>
        /// Processa teclas especiais
        /// ESC: Cancela
        /// Ctrl+S: Salva
        /// </summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            // ESC: Cancela
            if (keyData == Keys.Escape)
            {
                btnCancelar_Click(null, null);
                return true;
            }

            // Ctrl+S: Salva
            if (keyData == (Keys.Control | Keys.S))
            {
                btnSalvar_Click(null, null);
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        // ============================================
        // VALIDAÇÃO DE ENTRADA (APENAS NÚMEROS NO PREÇO)
        // ============================================

        /// <summary>
        /// Permite apenas números e vírgula no campo Preço
        /// </summary>
        private void txtPreco_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite: números, vírgula, ponto, backspace
            if (!char.IsControl(e.KeyChar) &&
                !char.IsDigit(e.KeyChar) &&
                e.KeyChar != ',' &&
                e.KeyChar != '.')
            {
                e.Handled = true; // Bloqueia caractere
            }

            // Permite apenas uma vírgula
            if ((e.KeyChar == ',' || e.KeyChar == '.') &&
                (txtPreco.Text.Contains(",") || txtPreco.Text.Contains(".")))
            {
                e.Handled = true;
            }
        }
    }

    // ============================================
    // CLASSE AUXILIAR: Categoria
    // ============================================

    /// <summary>
    /// Classe auxiliar para representar categoria
    /// Usada apenas no ComboBox deste formulário
    /// 
    /// NOTA: Em projeto maior, esta classe estaria
    /// na pasta Models, mas para simplicidade
    /// está aqui mesmo
    /// </summary>
    public class Categoria
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public override string ToString()
        {
            return Nome;
        }
    }
}