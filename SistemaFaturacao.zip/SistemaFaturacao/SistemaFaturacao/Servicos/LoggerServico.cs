﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using SistemaFaturacao.Interfaces;
using SistemaFaturacao.Models;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Excecoes;

namespace SistemaFaturacao.Servicos
{
    /// <summary>
    /// ============================================
    /// CLASSE: LoggerServico
    /// ============================================
    /// Implementa logging de tempo de execução
    /// 
    /// IMPLEMENTA: ILoggerServico
    /// 
    /// PADRÃO: Singleton (instância única)
    /// 
    /// FLUXO DE USO:
    /// 1. var logger = LoggerServico.Instancia;
    /// 2. var inicio = logger.IniciarOperacao("Nome");
    /// 3. // ... executar código ...
    /// 4. logger.FinalizarOperacao(inicio, "Detalhes");
    /// 
    /// ARMAZENAMENTO:
    /// - Em memória (lista _operacoesAtivas)
    /// - No BD (tabela LogsOperacoes)
    /// ============================================
    /// </summary>
    public class LoggerServico : ILoggerServico
    {
        // ============================================
        // SINGLETON
        // ============================================

        /// <summary>
        /// Instância única do logger (Singleton)
        /// STATIC: compartilhada globalmente
        /// VOLATILE: thread-safe
        /// </summary>
        private static volatile LoggerServico _instancia;

        /// <summary>
        /// Objeto para sincronização de threads
        /// </summary>
        private static readonly object _lock = new object();

        /// <summary>
        /// Dicionário de operações ativas
        /// KEY: nome da operação + timestamp
        /// VALUE: DateTime de início
        /// 
        /// USO: associar início com fim da mesma operação
        /// </summary>
        private readonly Dictionary<string, DateTime> _operacoesAtivas;

        // ============================================
        // CONSTRUTOR PRIVADO
        // ============================================

        /// <summary>
        /// Construtor privado (Singleton)
        /// Inicializa dicionário de operações
        /// </summary>
        private LoggerServico()
        {
            _operacoesAtivas = new Dictionary<string, DateTime>();
        }

        // ============================================
        // PROPRIEDADE: Instância (Singleton)
        // ============================================

        /// <summary>
        /// Obtém instância única do LoggerServico
        /// 
        /// ALGORITMO: Double-check locking (thread-safe)
        /// 
        /// RETORNO: instância única
        /// </summary>
        public static LoggerServico Instancia
        {
            get
            {
                if (_instancia == null)
                {
                    lock (_lock)
                    {
                        if (_instancia == null)
                        {
                            _instancia = new LoggerServico();
                        }
                    }
                }
                return _instancia;
            }
        }

        // ============================================
        // IMPLEMENTAÇÃO DA INTERFACE
        // ============================================

        /// <summary>
        /// Inicia registo de operação
        /// 
        /// FLUXO:
        /// 1. Captura DateTime.Now
        /// 2. Armazena em dicionário (opcional, para controle)
        /// 3. Retorna timestamp de início
        /// 
        /// PARÂMETRO: nomeOperacao - descrição da operação
        /// RETORNO: DateTime de início
        /// </summary>
        public DateTime IniciarOperacao(string nomeOperacao)
        {
            // Captura momento atual
            var inicio = DateTime.Now;

            // Gera chave única: nome + timestamp
            // Permite múltiplas operações com mesmo nome simultâneas
            string chave = $"{nomeOperacao}_{inicio.Ticks}";

            // Armazena no dicionário (thread-safe com lock)
            lock (_operacoesAtivas)
            {
                _operacoesAtivas[chave] = inicio;
            }

            return inicio;
        }

        /// <summary>
        /// Finaliza e grava log da operação
        /// 
        /// ALGORITMO:
        /// 1. Captura dataHoraFim
        /// 2. Calcula duração (fim - inicio)
        /// 3. Cria objeto LogOperacao
        /// 4. Grava no BD (tabela LogsOperacoes)
        /// 5. Remove do dicionário de ativos
        /// 
        /// PARÂMETROS:
        /// - dataHoraInicio: retornado por IniciarOperacao()
        /// - detalhes: informação adicional (opcional)
        /// 
        /// FLUXO DE EXCEÇÕES:
        /// - Captura erros mas não propaga (logging não deve quebrar app)
        /// - Registra erro no console/debug
        /// </summary>
        public void FinalizarOperacao(DateTime dataHoraInicio, string detalhes = "")
        {
            try
            {
                // 1. Captura momento de fim
                var dataHoraFim = DateTime.Now;

                // 2. Calcula duração
                TimeSpan duracao = dataHoraFim - dataHoraInicio;
                decimal tempoSegundos = (decimal)duracao.TotalSeconds;

                // 3. Extrai nome da operação do dicionário
                string nomeOperacao = "Operação Desconhecida";
                lock (_operacoesAtivas)
                {
                    // Busca operação ativa com este timestamp
                    foreach (var kvp in _operacoesAtivas)
                    {
                        if (kvp.Value == dataHoraInicio)
                        {
                            // Extrai nome (antes do underscore)
                            nomeOperacao = kvp.Key.Split('_')[0];
                            // Remove do dicionário
                            _operacoesAtivas.Remove(kvp.Key);
                            break;
                        }
                    }
                }

                // 4. Cria objeto de log
                var log = new LogOperacao
                {
                    Operacao = nomeOperacao,
                    DataHoraInicio = dataHoraInicio,
                    DataHoraFim = dataHoraFim,
                    TempoExecucaoSegundos = tempoSegundos,
                    Detalhes = detalhes
                };

                // 5. Grava no banco de dados
                GravarLogNoBD(log);
            }
            catch (Exception ex)
            {
                // Logging não deve quebrar aplicação
                // Apenas registra erro no debug
                System.Diagnostics.Debug.WriteLine(
                    $"Erro ao gravar log: {ex.Message}"
                );
            }
        }

        // ============================================
        // MÉTODOS PRIVADOS
        // ============================================

        /// <summary>
        /// Grava log no banco de dados
        /// 
        /// FLUXO:
        /// 1. Obtém conexão do pool
        /// 2. Cria comando INSERT
        /// 3. Adiciona parâmetros (previne SQL injection)
        /// 4. Executa query
        /// 5. Fecha conexão (devolve ao pool)
        /// 
        /// PARÂMETRO: log - objeto LogOperacao preenchido
        /// 
        /// ESTRUTURA TRY-CATCH:
        /// Captura erros mas não propaga
        /// </summary>
        private void GravarLogNoBD(LogOperacao log)
        {
            try
            {
                // 1. Obtém conexão do pool (using garante fechamento)
                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    // 2. Define query SQL
                    string sql = @"
                        INSERT INTO LogsOperacoes 
                        (Operacao, DataHoraInicio, DataHoraFim, TempoExecucaoSegundos, Detalhes)
                        VALUES 
                        (@Operacao, @DataHoraInicio, @DataHoraFim, @TempoExecucaoSegundos, @Detalhes)";

                    // 3. Cria comando com conexão
                    using (var comando = new MySqlCommand(sql, conexao))
                    {
                        // 4. Adiciona parâmetros (segurança contra SQL injection)
                        comando.Parameters.AddWithValue("@Operacao", log.Operacao);
                        comando.Parameters.AddWithValue("@DataHoraInicio", log.DataHoraInicio);
                        comando.Parameters.AddWithValue("@DataHoraFim", log.DataHoraFim);
                        comando.Parameters.AddWithValue("@TempoExecucaoSegundos", log.TempoExecucaoSegundos);
                        comando.Parameters.AddWithValue("@Detalhes", log.Detalhes ?? "");

                        // 5. Executa INSERT
                        // ExecuteNonQuery: usado para INSERT/UPDATE/DELETE
                        // Retorna número de linhas afetadas
                        comando.ExecuteNonQuery();
                    }
                }
                // 6. Conexão fechada automaticamente (using)
                // e devolvida ao pool
            }
            catch (MySqlException ex)
            {
                // Erro MySQL específico
                System.Diagnostics.Debug.WriteLine(
                    $"Erro MySQL ao gravar log: {ex.Message}"
                );
            }
            catch (Exception ex)
            {
                // Qualquer outro erro
                System.Diagnostics.Debug.WriteLine(
                    $"Erro inesperado ao gravar log: {ex.Message}"
                );
            }
        }
    }
}