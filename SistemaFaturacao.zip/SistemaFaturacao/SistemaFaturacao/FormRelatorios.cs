﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using SistemaFaturacao.Repositorios;
using SistemaFaturacao.Models;

namespace SistemaFaturacao
{
    /// <summary>
    /// Formulário de relatórios e logs de performance
    /// Visualiza tempos de execução de operações
    /// </summary>
    public partial class FormRelatorios : Form
    {
        private List<LogOperacao> _logs;

        public FormRelatorios()
        {
            InitializeComponent();
            _logs = new List<LogOperacao>();
        }

        private void FormRelatorios_Load(object sender, EventArgs e)
        {
            try
            {
                ConfigurarDataGridView();
                CarregarOperacoes();
                CarregarLogs();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erro ao carregar relatórios:\n\n{ex.Message}",
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void ConfigurarDataGridView()
        {
            dgvLogs.AutoGenerateColumns = false;
            dgvLogs.Columns.Clear();

            dgvLogs.Columns.Add("colId", "ID");
            dgvLogs.Columns["colId"].Width = 50;

            dgvLogs.Columns.Add("colOperacao", "Operação");
            dgvLogs.Columns["colOperacao"].Width = 200;

            dgvLogs.Columns.Add("colInicio", "Data/Hora Início");
            dgvLogs.Columns["colInicio"].Width = 150;
            dgvLogs.Columns["colInicio"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";

            dgvLogs.Columns.Add("colFim", "Data/Hora Fim");
            dgvLogs.Columns["colFim"].Width = 150;
            dgvLogs.Columns["colFim"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";

            dgvLogs.Columns.Add("colTempo", "Tempo (s)");
            dgvLogs.Columns["colTempo"].Width = 100;
            dgvLogs.Columns["colTempo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvLogs.Columns.Add("colDetalhes", "Detalhes");
            dgvLogs.Columns["colDetalhes"].Width = 150;

            dgvLogs.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgvLogs.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            dgvLogs.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvLogs.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        }

        private void CarregarOperacoes()
        {
            try
            {
                var operacoes = new List<string> { "Todas as Operações" };

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = "SELECT DISTINCT Operacao FROM LogsOperacoes ORDER BY Operacao";
                    using (var cmd = new MySqlCommand(sql, conexao))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            operacoes.Add(reader.GetString("Operacao"));
                        }
                    }
                }

                cboOperacao.DataSource = operacoes;
                cboOperacao.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar operações: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CarregarLogs(string filtroOperacao = null)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                _logs.Clear();

                using (var conexao = ConexaoBD.Instancia.ObterConexao())
                {
                    string sql = @"
                        SELECT LogId, Operacao, DataHoraInicio, DataHoraFim, 
                               TempoExecucaoSegundos, Detalhes
                        FROM LogsOperacoes";

                    if (!string.IsNullOrEmpty(filtroOperacao))
                    {
                        sql += " WHERE Operacao = @Operacao";
                    }

                    sql += " ORDER BY DataHoraInicio DESC LIMIT 100";

                    using (var cmd = new MySqlCommand(sql, conexao))
                    {
                        if (!string.IsNullOrEmpty(filtroOperacao))
                        {
                            cmd.Parameters.AddWithValue("@Operacao", filtroOperacao);
                        }

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _logs.Add(new LogOperacao
                                {
                                    Id = reader.GetInt32("LogId"),
                                    Operacao = reader.GetString("Operacao"),
                                    DataHoraInicio = reader.GetDateTime("DataHoraInicio"),
                                    DataHoraFim = reader.GetDateTime("DataHoraFim"),
                                    TempoExecucaoSegundos = reader.GetDecimal("TempoExecucaoSegundos"),
                                    Detalhes = reader.IsDBNull(reader.GetOrdinal("Detalhes"))
                                        ? ""
                                        : reader.GetString("Detalhes")
                                });
                            }
                        }
                    }
                }

                AtualizarGrid();
                CalcularEstatisticas();
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show($"Erro ao carregar logs: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AtualizarGrid()
        {
            dgvLogs.Rows.Clear();

            foreach (var log in _logs)
            {
                dgvLogs.Rows.Add(
                    log.Id,
                    log.Operacao,
                    log.DataHoraInicio,
                    log.DataHoraFim,
                    $"{log.TempoExecucaoSegundos:F3}",
                    log.Detalhes
                );
            }
        }

        private void CalcularEstatisticas()
        {
            if (_logs.Count == 0)
            {
                lblTotalOperacoes.Text = "0";
                lblTempoMedio.Text = "0,000s";
                lblMaisRapida.Text = "0,000s";
                lblMaisLenta.Text = "0,000s";
                return;
            }

            lblTotalOperacoes.Text = _logs.Count.ToString();
            lblTempoMedio.Text = $"{_logs.Average(l => l.TempoExecucaoSegundos):F3}s";
            lblMaisRapida.Text = $"{_logs.Min(l => l.TempoExecucaoSegundos):F3}s";
            lblMaisLenta.Text = $"{_logs.Max(l => l.TempoExecucaoSegundos):F3}s";
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            string operacao = cboOperacao.SelectedItem?.ToString();

            if (operacao == "Todas as Operações")
            {
                CarregarLogs();
            }
            else
            {
                CarregarLogs(operacao);
            }
        }

        private void btnTodos_Click(object sender, EventArgs e)
        {
            cboOperacao.SelectedIndex = 0;
            CarregarLogs();
        }
    }
}